"use client"

import dynamic from "next/dynamic"
import { useEffect, useState, useMemo, useCallback } from "react"
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from "recharts"

// Types
interface EducationData {
  NAMA_KAB: string
  NAMA_KEC: string
  NAMA_DESA: string
  total_paud: number
  total_tk: number
  total_sd: number
  total_mi: number
  total_smp: number
  total_mts: number
  total_sma: number
  total_ma: number
  total_smk: number
  skor_paud: number 
  skor_sd: number 
  skor_smp: number 
  skor_sma: number 
  skor_literasi: number 
  skor_pendidikan_total: number 
  kategori_pendidikan: string
  cluster: number
  label: string
  Latitude: number
  Longitude: number
}

// Dynamic Import
const MapComponent = dynamic(() => import("./MapComponent"), {
  ssr: false,
  loading: () => (
    <div className="h-96 bg-white/80 backdrop-blur-sm rounded-lg animate-pulse" />
  ),
})

// Constants
const COLORS = ["#1d2415", "#697857", "#37432b", "#8b907c", "#a8a97a"]
const ITEMS_PER_PAGE = 10

// Helpers
const safeToFixed = (value: number | null, decimals = 1): string => {
  return value === null ? "N/A" : Number(value).toFixed(decimals)
}

// Main Component
export default function PendidikanPage() {
  // ============ STATE ============
  const [data, setData] = useState<EducationData[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")
  const [currentPage, setCurrentPage] = useState(1)

  // Filter State
  const [selectedKab, setSelectedKab] = useState<string>("")
  const [selectedKec, setSelectedKec] = useState<string>("")
  const [selectedDesa, setSelectedDesa] = useState<string>("")
  const [kecamatanOptions, setKecamatanOptions] = useState<string[]>([])
  const [desaOptions, setDesaOptions] = useState<string[]>([])

  // Derived data for charts
  const [chartDataForKecamatan, setChartDataForKecamatan] = useState<EducationData[]>([])

  // Pagination
  const [filteredData, setFilteredData] = useState<EducationData[]>([])
  const [paginatedData, setPaginatedData] = useState<EducationData[]>([])

  // ============ EFFECTS ============

  // 🔹 Fetch Education Data (only once)
  useEffect(() => {
    const controller = new AbortController()
    const fetchData = async () => {
      try {
        const response = await fetch("http://localhost:8000/api/data_cluster/cluster_pendidikan", {
          signal: controller.signal,
        })
        const result = await response.json()
        if (Array.isArray(result)) {
          setData(result)
        }
      } catch (error) {
        if (!(error instanceof DOMException && error.name === "AbortError")) {
          console.error("Error fetching education data:", error)
        }
      } finally {
        setLoading(false)
      }
    }

    fetchData()
    return () => controller.abort()
  }, [])

  // 🔹 Update chartDataForKecamatan
  useEffect(() => {
    const filtered = data.filter(
      (item) => item.NAMA_KAB === selectedKab && item.NAMA_KEC === selectedKec
    )
    setChartDataForKecamatan(filtered)
  }, [data, selectedKab, selectedKec])

  // 🔹 Kecamatan options
  useEffect(() => {
    if (selectedKab) {
      const kecs = [...new Set(data.filter(d => d.NAMA_KAB === selectedKab).map(d => d.NAMA_KEC))]
      setKecamatanOptions(kecs)
      setSelectedKec("")
      setSelectedDesa("")
    } else {
      setKecamatanOptions([])
      setSelectedKec("")
      setSelectedDesa("")
    }
  }, [selectedKab, data])

  // 🔹 Desa options
  useEffect(() => {
    if (selectedKab && selectedKec) {
      const desas = [...new Set(
        data
          .filter(d => d.NAMA_KAB === selectedKab && d.NAMA_KEC === selectedKec)
          .map(d => d.NAMA_DESA)
      )]
      setDesaOptions(desas)
      setSelectedDesa("")
    } else {
      setDesaOptions([])
      setSelectedDesa("")
    }
  }, [selectedKab, selectedKec, data])

  // 🔹 Search & Pagination
  useEffect(() => {
    const filtered = data.filter(item =>
      item.NAMA_DESA.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.NAMA_KEC.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.NAMA_KAB.toLowerCase().includes(searchTerm.toLowerCase())
    )
    setFilteredData(filtered)
    setTotalPages(Math.ceil(filtered.length / ITEMS_PER_PAGE))
    setCurrentPage(1)
  }, [data, searchTerm])

  // 🔹 Apply pagination
  useEffect(() => {
    const start = (currentPage - 1) * ITEMS_PER_PAGE
    const end = start + ITEMS_PER_PAGE
    setPaginatedData(filteredData.slice(start, end))
    setStartIndex(start)
    setEndIndex(end)
  }, [currentPage, filteredData])

  // ============ COMPUTED VALUES ============

  const validData = useMemo(() =>
    data.filter(item =>
      item.skor_paud != null &&
      item.skor_sd != null &&
      item.skor_smp != null &&
      item.skor_sma != null &&
      item.skor_pendidikan_total != null
    ), [data])

  const [startIndex, setStartIndex] = useState(0)
  const [endIndex, setEndIndex] = useState(0)
  const [totalPages, setTotalPages] = useState(0)

  // 💡 Charts
  const pendidikanByKabupaten = useMemo(() =>
    chartDataForKecamatan
      .map(item => ({
        name: item.NAMA_DESA,
        skor: Number((item.skor_pendidikan_total || 0).toFixed(1)),
      }))
      .sort((a, b) => b.skor - a.skor),
    [chartDataForKecamatan]
  )

  const levelByDesa = useMemo(() => {
    const desa = data.find(
      item => item.NAMA_KAB === selectedKab &&
               item.NAMA_KEC === selectedKec &&
               item.NAMA_DESA === selectedDesa
    )
    if (!desa) return []
    return [
      { name: "PAUD", skor: Number((desa.skor_paud || 0).toFixed(1)) },
      { name: "SD", skor: Number((desa.skor_sd || 0).toFixed(1)) },
      { name: "SMP", skor: Number((desa.skor_smp || 0).toFixed(1)) },
      { name: "SMA", skor: Number((desa.skor_sma || 0).toFixed(1)) },
    ]
  }, [data, selectedKab, selectedKec, selectedDesa])

  const skorComponentChartData = useMemo(() => {
    if (validData.length === 0) return []
    const avg = (key: keyof EducationData) =>
      Number((validData.reduce((sum, item) => sum + (Number(item[key]) || 0), 0) / validData.length).toFixed(1))
    return [
      { name: "PAUD", avg: avg("skor_paud") },
      { name: "SD", avg: avg("skor_sd") },
      { name: "SMP", avg: avg("skor_smp") },
      { name: "SMA", avg: avg("skor_sma") },
      { name: "Literasi", avg: avg("skor_literasi") },
    ]
  }, [validData])

  const fasilitasByDesa = useMemo(() => {
    const desa = data.find(
      item => item.NAMA_KAB === selectedKab &&
               item.NAMA_KEC === selectedKec &&
               item.NAMA_DESA === selectedDesa
    )
    if (!desa) return []
    return [
      { name: "PAUD", count: desa.total_paud || 0 },
      { name: "TK", count: desa.total_tk || 0 },
      { name: "SD", count: desa.total_sd || 0 },
      { name: "SMP", count: desa.total_smp || 0 },
      { name: "SMA", count: desa.total_sma || 0 },
      { name: "SMK", count: desa.total_smk || 0 },
    ]
  }, [data, selectedKab, selectedKec, selectedDesa])

  const categoryDistribution = useMemo(() => {
    return chartDataForKecamatan.reduce((acc, item) => {
      if (!item.kategori_pendidikan) return acc
      const existing = acc.find(x => x.name === item.kategori_pendidikan)
      if (existing) {
        existing.value += 1
      } else {
        acc.push({ name: item.kategori_pendidikan, value: 1 })
      }
      return acc
    }, [] as Array<{ name: string; value: number }>)
  }, [chartDataForKecamatan])

  const skorByKecamatan = useMemo(() => {
    if (!selectedKab) return []
    const grouped = data
      .filter(item => item.NAMA_KAB === selectedKab)
      .reduce((acc, item) => {
        if (!acc[item.NAMA_KEC]) {
          acc[item.NAMA_KEC] = { totalSkor: 0, count: 0 }
        }
        acc[item.NAMA_KEC].totalSkor += (item.skor_pendidikan_total || 0)
        acc[item.NAMA_KEC].count += 1
        return acc
      }, {} as Record<string, { totalSkor: number; count: number }>)

    return Object.entries(grouped).map(([kec, { totalSkor, count }]) => ({
      name: kec,
      avgSkor: Number((totalSkor / count).toFixed(1))
    })).sort((a, b) => b.avgSkor - a.avgSkor)
  }, [data, selectedKab])

  // 📊 Stats
  const stats = useMemo(() => {
    const totalDesa = chartDataForKecamatan.length
    const totalSekolah = chartDataForKecamatan.reduce((sum, item) =>
      sum + (item.total_sd || 0) + (item.total_smp || 0) + (item.total_sma || 0), 0
    )

    if (validData.length === 0) {
      return { totalDesa, avgPendidikan: "0.0", avgLiterasi: "0.0", totalSekolah }
    }

    const avgPendidikan = (
      chartDataForKecamatan.reduce((sum, item) => sum + (Number(item.skor_pendidikan_total) || 0), 0) / chartDataForKecamatan.length
    ).toFixed(1)
    const avgLiterasi = (
      chartDataForKecamatan.reduce((sum, item) => sum + (Number(item.skor_literasi) || 0), 0) / chartDataForKecamatan.length
    ).toFixed(1)

    return { totalDesa, avgPendidikan, avgLiterasi, totalSekolah }
  }, [chartDataForKecamatan, validData])

  // 🗺️ Map Markers
  const mapMarkers = useMemo(() => {
    return chartDataForKecamatan
      .filter(item =>
        typeof item.Latitude === 'number' &&
        typeof item.Longitude === 'number' &&
        !isNaN(item.Latitude) &&
        !isNaN(item.Longitude)
      )
      .map(item => ({
        name: item.NAMA_DESA,
        position: [item.Latitude, item.Longitude] as [number, number],
        kabupaten: item.NAMA_KAB,
        kecamatan: item.NAMA_KEC,
        skorEkonomi: item.skor_pendidikan_total,
        skorLiterasi: item.skor_literasi,
      }))
  }, [chartDataForKecamatan])

  // ============ RENDER ============
  if (loading) {
    return <div className="p-8 text-black">Loading...</div>
  }

  return (
    <div className="space-y-6 p-8">
      {/* Header */}
      <div className="flex items-start justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-black mb-2">Analisis Pendidikan Desa</h1>
          <p className="text-gray-600">Data kluster pendidikan masyarakat per desa</p>
        </div>
        <div className="flex gap-3 flex-wrap justify-end">
          {/* Filter Kabupaten */}
          <div className="flex flex-col gap-1">
            <label className="text-xs font-bold text-gray-600">Filter Kabupaten</label>
            <select
              value={selectedKab}
              onChange={(e) => setSelectedKab(e.target.value)}
              className="px-3 py-2 bg-white border border-[#c9ece7] rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-[#5fb8a8]"
            >
              <option value="">Semua Kabupaten</option>
              {[...new Set(data.map(d => d.NAMA_KAB))].map(kab => (
                <option key={kab} value={kab}>{kab}</option>
              ))}
            </select>
          </div>

          {/* Filter Kecamatan */}
          <div className="flex flex-col gap-1">
            <label className="text-xs font-bold text-gray-600">Filter Kecamatan</label>
            <select
              value={selectedKec}
              onChange={(e) => setSelectedKec(e.target.value)}
              className="px-3 py-2 bg-white border border-[#c9ece7] rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-[#5fb8a8]"
              disabled={!selectedKab}
            >
              <option value="">Semua Kecamatan</option>
              {kecamatanOptions.map(kec => (
                <option key={kec} value={kec}>{kec}</option>
              ))}
            </select>
          </div>

          {/* Filter Desa */}
          <div className="flex flex-col gap-1">
            <label className="text-xs font-bold text-gray-600">Filter Desa</label>
            <select
              value={selectedDesa}
              onChange={(e) => setSelectedDesa(e.target.value)}
              className="px-3 py-2 bg-white border border-[#c9ece7] rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-[#5fb8a8]"
              disabled={!selectedKec}
            >
              <option value="">Semua Desa</option>
              {desaOptions.map(desa => (
                <option key={desa} value={desa}>{desa}</option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {[
          { label: "Total Desa", value: stats.totalDesa },
          { label: "Rata-rata Skor Pendidikan", value: stats.avgPendidikan },
          { label: "Rata-rata Skor Literasi", value: stats.avgLiterasi },
          { label: "Total Sekolah", value: stats.totalSekolah },
        ].map((item, i) => (
          <div key={i} className="border border-[#c9ece7] bg-white/80 backdrop-blur-sm rounded-lg p-6">
            <p className="text-black text-sm font-medium">{item.label}</p>
            <p className="text-3xl font-bold text-black mt-2">{item.value}</p>
          </div>
        ))}
      </div>

      {/* Map */}
      <div className="bg-white/80 backdrop-blur-sm border border-[#c9ece7] rounded-lg overflow-hidden">
        <h2 className="text-lg font-semibold text-black p-3 pb-2">
          Sebaran Desa di Jawa Timur ({mapMarkers.length} desa)
        </h2>
        <div className="h-96 w-full">
          {/* ✅ Tambahkan key agar peta benar-benar refresh saat marker berubah */}
          <MapComponent key={`${selectedKab}-${selectedKec}`} markers={mapMarkers} />
        </div>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Chart 1 */}
        <ChartCard title="Rata-rata Skor Komponen Pendidikan (Nasional)">
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={skorComponentChartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e0e0e0" />
              <XAxis dataKey="name" stroke="#666" fontSize={12} />
              <YAxis stroke="#666" />
              <Tooltip contentStyle={{ backgroundColor: "#f5f5f5", border: "1px solid #ccc" }} />
              <Bar dataKey="avg" fill="#697857" name="Skor Rata-rata" />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        {/* Chart 2 */}
        <ChartCard title="Skor Pendidikan per Desa di Kecamatan Terpilih">
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={pendidikanByKabupaten}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e0e0e0" />
              <XAxis dataKey="name" stroke="#666" angle={-45} textAnchor="end" height={80} fontSize={12} />
              <YAxis stroke="#666" />
              <Tooltip contentStyle={{ backgroundColor: "#f5f5f5", border: "1px solid #ccc" }} />
              <Bar dataKey="skor" fill="#1d2415" name="Skor Pendidikan" />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        {/* Chart 3 */}
        <ChartCard title={`Distribusi Kategori Pendidikan ${selectedKec ? `di Kec. ${selectedKec}` : "(Pilih kecamatan)"}`}>
          <ResponsiveContainer width="100%" height={300}>
            {categoryDistribution.length > 0 ? (
              <PieChart>
                <Pie
                  data={categoryDistribution}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {categoryDistribution.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            ) : (
              <div className="flex items-center justify-center h-full text-gray-500">
                Tidak ada data kategori
              </div>
            )}
          </ResponsiveContainer>
        </ChartCard>

        {/* Chart 4 */}
        <ChartCard title={`Skor Jenjang Pendidikan ${selectedDesa ? `di ${selectedDesa}` : "(Pilih satu desa)"}`}>
          <ResponsiveContainer width="100%" height={320}>
            <BarChart layout="vertical" data={levelByDesa} margin={{ bottom: 30, top: 10 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e0e0e0" />
              <XAxis type="number" stroke="#666" domain={[0, 5]} />
              <YAxis dataKey="name" type="category" stroke="#666" fontSize={14} />
              <Tooltip />
              <Bar dataKey="skor">
                {levelByDesa.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={["#1d2415", "#697857", "#37432b", "#8b907c"][index]} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        {/* Chart 5 */}
        <ChartCard title={`Total Fasilitas Pendidikan ${selectedDesa ? `di ${selectedDesa}` : "(Pilih satu desa)"}`}>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={fasilitasByDesa}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e0e0e0" />
              <XAxis dataKey="name" stroke="#666" angle={-45} textAnchor="end" height={80} fontSize={11} />
              <YAxis stroke="#666" />
              <Tooltip contentStyle={{ backgroundColor: "#f5f5f5", border: "1px solid #ccc" }} />
              <Bar dataKey="count" fill="#37432b" name="Jumlah" />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        {/* Chart 6 */}
        <ChartCard title={`Rata-rata Skor Pendidikan per Kecamatan ${selectedKab ? `di ${selectedKab}` : "(Pilih kabupaten)"}`}>
          <ResponsiveContainer width="100%" height={300}>
            {skorByKecamatan.length > 0 ? (
              <BarChart layout="vertical" data={skorByKecamatan} margin={{ top: 10, right: 30, left: 20, bottom: 10 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e0e0e0" />
                <XAxis type="number" stroke="#666" domain={[0, 5]} />
                <YAxis dataKey="name" type="category" stroke="#666" fontSize={12} />
                <Tooltip contentStyle={{ backgroundColor: "#f5f5f5", border: "1px solid #ccc" }} />
                <Bar dataKey="avgSkor" fill="#37432b" name="Rata-rata Skor" />
              </BarChart>
            ) : (
              <div className="flex items-center justify-center h-full text-gray-500">
                Pilih kabupaten untuk melihat data
              </div>
            )}
          </ResponsiveContainer>
        </ChartCard>
      </div>

      {/* Table */}
      <div className="border border-[#c9ece7] bg-white/80 backdrop-blur-sm rounded-lg p-6">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-6">
          <h2 className="text-lg font-semibold text-black">Detail Pendidikan Desa</h2>
          <input
            type="text"
            placeholder="Cari nama desa, kecamatan, atau kabupaten ..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="px-4 py-2 border border-[#c9ece7] rounded-lg bg-white text-black placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-[#5fb8a8]"
          />
        </div>

        <div className="overflow-x-auto">
          <table className="w-full border-collapse">
            <thead>
              <tr className="border-b border-[#c9ece7] bg-gray-50">
                {["No", "Kabupaten", "Kecamatan", "Desa", "PAUD", "SD", "SMP", "SMA", "Literasi", "Total Skor", "Kategori"]
                  .map((header, i) => (
                    <th key={i} className="px-4 py-3 text-left text-black font-semibold text-sm">{header}</th>
                  ))}
              </tr>
            </thead>
            <tbody>
              {paginatedData.length > 0 ? (
                paginatedData.map((item, index) => (
                  <tr key={index} className="border-b border-[#e0e0e0] hover:bg-gray-50 transition-colors">
                    <td className="px-4 py-3 text-black text-sm">{startIndex + index + 1}</td>
                    <td className="px-4 py-3 text-black text-sm">{item.NAMA_KAB}</td>
                    <td className="px-4 py-3 text-black text-sm">{item.NAMA_KEC}</td>
                    <td className="px-4 py-3 text-black font-medium text-sm">{item.NAMA_DESA}</td>
                    <td className="px-4 py-3 text-black text-sm">{safeToFixed(item.skor_paud)}</td>
                    <td className="px-4 py-3 text-black text-sm">{safeToFixed(item.skor_sd)}</td>
                    <td className="px-4 py-3 text-black text-sm">{safeToFixed(item.skor_smp)}</td>
                    <td className="px-4 py-3 text-black text-sm">{safeToFixed(item.skor_sma)}</td>
                    <td className="px-4 py-3 text-black text-sm">{safeToFixed(item.skor_literasi)}</td>
                    <td className="px-4 py-3 text-black font-semibold text-sm">
                      {safeToFixed(item.skor_pendidikan_total)}
                    </td>
                    <td className="px-4 py-3 text-sm">
                      <span className="inline-block px-3 py-1 bg-gray-100 text-gray-800 rounded-full text-xs font-medium">
                        {item.kategori_pendidikan}
                      </span>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={11} className="px-4 py-6 text-center text-gray-500">
                    Tidak ada data ditemukan
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mt-6 pt-6 border-t border-[#c9ece7]">
          <div className="text-black text-sm">
            Menampilkan {paginatedData.length > 0 ? startIndex + 1 : 0} - {Math.min(endIndex, filteredData.length)} dari{" "}
            {filteredData.length.toLocaleString()} data
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setCurrentPage((prev) => Math.max(prev - 1, 1))}
              disabled={currentPage === 1}
              className="px-4 py-2 border border-[#c9ece7] rounded-lg text-black font-medium disabled:opacity-50 disabled:cursor-not-allowed hover:bg-gray-50 transition-colors"
            >
              Sebelumnya
            </button>
            <div className="flex items-center gap-1">
              <span className="text-black text-sm">Halaman</span>
              <input
                type="number"
                min="1"
                max={totalPages}
                value={currentPage}
                onChange={(e) => {
                  const page = Math.max(1, Math.min(totalPages, parseInt(e.target.value) || 1))
                  setCurrentPage(page)
                }}
                className="w-16 px-2 py-2 border border-[#c9ece7] rounded-lg text-black text-center focus:outline-none focus:ring-2 focus:ring-[#5fb8a8]"
              />
              <span className="text-black text-sm">dari {totalPages}</span>
            </div>
            <button
              onClick={() => setCurrentPage((prev) => Math.min(prev + 1, totalPages))}
              disabled={currentPage === totalPages}
              className="px-4 py-2 border border-[#c9ece7] rounded-lg text-black font-medium disabled:opacity-50 disabled:cursor-not-allowed hover:bg-gray-50 transition-colors"
            >
              Selanjutnya
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}

// ✨ Reusable Chart Card
const ChartCard = ({ title, children }: { title: string; children: React.ReactNode }) => (
  <div className="border border-[#c9ece7] bg-white/80 backdrop-blur-sm rounded-lg p-6">
    <h2 className="text-lg font-semibold text-black mb-4">{title}</h2>
    {children}
  </div>
)