"use client"

import { useEffect, useState } from "react"
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from "recharts"

interface LingkunganData {
  IDDESA: string
  NAMA_KAB: string
  NAMA_KEC: string
  NAMA_DESA: string
  skor_pengelolaan_sampah: number
  total_pencemaran: number
  skor_kualitas_lingkungan: number
  total_bencana: number
  tingkat_kerawanan: number
  skor_ketahanan_bencana: number
  skor_mitigasi_bencana: number
  skor_pelestarian: number
  skor_lingkungan_total: number
  kategori_lingkungan: string
  cluster: number
  label: string
  Latitude : number
  Longitude : number
}

const COLORS = ["#1d2415", "#697857", "#37432b", "#8b907c", "#a8a97a"]
const ITEMS_PER_PAGE = 10

export default function LingkunganPage() {
  const [data, setData] = useState<LingkunganData[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")
  const [currentPage, setCurrentPage] = useState(1)
  const [filteredData, setFilteredData] = useState<LingkunganData[]>([])
  const [totalPages, setTotalPages] = useState(0)
  const [startIndex, setStartIndex] = useState(0)
  const [endIndex, setEndIndex] = useState(0)
  const [paginatedData, setPaginatedData] = useState<LingkunganData[]>([])

// Filter State
  const [selectedKab, setSelectedKab] = useState<string>("")
  const [selectedKec, setSelectedKec] = useState<string>("")
  const [selectedDesa, setSelectedDesa] = useState<string>("")
  const [kecamatanOptions, setKecamatanOptions] = useState<string[]>([])
  const [desaOptions, setDesaOptions] = useState<string[]>([])
  const [chartDataForKecamatan, setChartDataForKecamatan] = useState<LingkunganData[]>([])

  // Efek untuk data chart (hanya kab & kec)
  useEffect(() => {
    let newChartData = data.filter(
      (item) =>
        item.NAMA_KAB === selectedKab && item.NAMA_KEC === selectedKec
    )

    setChartDataForKecamatan(newChartData)
  }, [data, selectedKab, selectedKec])

  // Update kecamatan options saat kabupaten berubah
  useEffect(() => {
    if (selectedKab) {
      const kecList = [...new Set(data.filter(d => d.NAMA_KAB === selectedKab).map(d => d.NAMA_KEC))]
      setKecamatanOptions(kecList)
      setSelectedKec("")
      setSelectedDesa("")
    } else {
      setKecamatanOptions([])
      setSelectedKec("")
      setSelectedDesa("")
    }
  }, [selectedKab, data])

  // Update desa options saat kecamatan berubah
  useEffect(() => {
    if (selectedKec && selectedKab) {
      const desaList = [...new Set(data.filter(d => d.NAMA_KEC === selectedKec && d.NAMA_KAB === selectedKab).map(d => d.NAMA_DESA))]
      setDesaOptions(desaList)
      setSelectedDesa("")
    } else {
      setDesaOptions([])
      setSelectedDesa("")
    }
  }, [selectedKec, selectedKab, data])

  // Filter data berdasarkan pencarian dan dropdown
  useEffect(() => {
    let newFilteredData = data.filter(
      (item) =>
        item.NAMA_DESA.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item.NAMA_KEC.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item.NAMA_KAB.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item.label.toLowerCase().includes(searchTerm.toLowerCase())
    )

    if (selectedKab) newFilteredData = newFilteredData.filter(item => item.NAMA_KAB === selectedKab)
    if (selectedKec) newFilteredData = newFilteredData.filter(item => item.NAMA_KEC === selectedKec)

    setFilteredData(newFilteredData)
    setTotalPages(Math.ceil(newFilteredData.length / ITEMS_PER_PAGE))
    setCurrentPage(1)
  }, [data, searchTerm, selectedKab, selectedKec])


  // Fetch Data
  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch("http://localhost:8000/api/data_cluster/cluster_lingkungan")
        const result = await response.json()
        if (Array.isArray(result)) {
          setData(result)
        } else {
          console.error("API tidak mengembalikan array:", result)
          setData([])
        }
      } catch (error) {
        console.error("Error fetching lingkungan data:", error)
        setData([])
      } finally {
        setLoading(false)
      }
    }

    fetchData()
  }, [])

  // Pagination
  useEffect(() => {
    const newStartIndex = (currentPage - 1) * ITEMS_PER_PAGE
    const newEndIndex = newStartIndex + ITEMS_PER_PAGE
    setStartIndex(newStartIndex)
    setEndIndex(newEndIndex)
    setPaginatedData(filteredData.slice(newStartIndex, newEndIndex))
  }, [currentPage, filteredData])

  // Chart 1: Rata-rata Skor Lingkungan per Kabupaten
  const skorLingkunganPerDesa = chartDataForKecamatan.map(item => ({
    name: item.NAMA_DESA,
    skor: Number(item.skor_lingkungan_total.toFixed(1)),
  }))

  // Chart 2: Rata-rata Kualitas Lingkungan per Kabupaten
  const kualitasLingkunganPerDesa = chartDataForKecamatan.map(item => ({
    name: item.NAMA_DESA,
    skor: Number(item.skor_kualitas_lingkungan.toFixed(1)),
  }))

  // Chart 3: Rata-rata Komponen Lingkungan Nasional
  const komponenLingkunganNasional = [
    {
      name: "Pengelolaan Sampah",
      avg: Number((filteredData.reduce((sum, item) => sum + item.skor_pengelolaan_sampah, 0) / filteredData.length).toFixed(1)),
    },
    {
      name: "Ketahanan Bencana",
      avg: Number((filteredData.reduce((sum, item) => sum + item.skor_ketahanan_bencana, 0) / filteredData.length).toFixed(1)),
    },
    {
      name: "Mitigasi Bencana",
      avg: Number((filteredData.reduce((sum, item) => sum + item.skor_mitigasi_bencana, 0) / filteredData.length).toFixed(1)),
    },
    {
      name: "Pelestarian",
      avg: Number((filteredData.reduce((sum, item) => sum + item.skor_pelestarian, 0) / filteredData.length).toFixed(1)),
    },
  ]

  // Chart 4: Distribusi Kategori Lingkungan
  const distribusiKategori = chartDataForKecamatan.reduce((acc, item) => {
    const existing = acc.find((x) => x.name === item.kategori_lingkungan)
    if (existing) {
      existing.value += 1
    } else {
      acc.push({ name: item.kategori_lingkungan, value: 1 })
    }
    return acc
  }, [] as Array<{ name: string; value: number }>)

  // Chart 5: Distribusi Cluster (Label)
  const distribusiCluster = chartDataForKecamatan.reduce((acc, item) => {
    const existing = acc.find((x) => x.name === item.label)
    if (existing) {
      existing.value += 1
    } else {
      acc.push({ name: item.label, value: 1 })
    }
    return acc
  }, [] as Array<{ name: string; value: number }>)
  
  // Stats
  const stats = {
    totalDesa: filteredData.length,
    avgLingkungan: filteredData.length > 0 ? (filteredData.reduce((sum, item) => sum + item.skor_lingkungan_total, 0) / filteredData.length).toFixed(1) : "0.0",
    avgKualitas: filteredData.length > 0 ? (filteredData.reduce((sum, item) => sum + item.skor_kualitas_lingkungan, 0) / filteredData.length).toFixed(1) : "0.0",
    avgSampah: filteredData.length > 0 ? (filteredData.reduce((sum, item) => sum + item.skor_pengelolaan_sampah, 0) / filteredData.length).toFixed(1) : "0.0",
  }

  if (loading) {
    return <div className="p-8 text-black">Loading...</div>
  }

  return (
    <div className="space-y-6 p-8">
      <div className="flex items-start justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-black mb-2">Analisis Lingkungan Desa</h1>
          <p className="text-gray-600">Data kluster lingkungan dan keberlanjutan per desa</p>
        </div>
        <div className="flex gap-3 flex-wrap justify-end">
          <div className="flex flex-col gap-1">
            <label className="text-xs font-bold text-muted-foreground">Filter Kabupaten</label>
            <select 
              value={selectedKab}
              onChange={(e) => setSelectedKab(e.target.value)}
              className="px-3 py-2 bg-white border border-border rounded-md text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
            >
              <option value="">Semua Kabupaten</option>
              {[...new Set(data.map(d => d.NAMA_KAB))].map(kab => (
                <option key={kab} value={kab}>{kab}</option>
              ))}
            </select>
          </div>

          <div className="flex flex-col gap-1">
            <label className="text-xs font-bold text-muted-foreground">Filter Kecamatan</label>
            <select 
              value={selectedKec}
              onChange={(e) => setSelectedKec(e.target.value)}
              className="px-3 py-2 bg-white border border-border rounded-md text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
              disabled={!selectedKab}
            >
              <option value="">Semua Kecamatan</option>
              {kecamatanOptions.map(kec => (
                <option key={kec} value={kec}>{kec}</option>
              ))}
            </select>
          </div>

          <div className="flex flex-col gap-1">
            <label className="text-xs font-bold text-muted-foreground">Filter Desa</label>
            <select 
              value={selectedDesa}
              onChange={(e) => setSelectedDesa(e.target.value)}
              className="px-3 py-2 bg-white border border-border rounded-md text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
              disabled={!selectedKec}
            >
              <option value="">Semua Desa</option>
              {desaOptions.map(desa => (
                <option key={desa} value={desa}>{desa}</option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="border border-[#c9ece7] bg-white/80 backdrop-blur-sm rounded-lg p-6">
          <p className="text-black text-sm font-medium">Total Desa</p>
          <p className="text-3xl font-bold text-black mt-2">{stats.totalDesa}</p>
        </div>
        <div className="border border-[#c9ece7] bg-white/80 backdrop-blur-sm rounded-lg p-6">
          <p className="text-black text-sm font-medium">Rata-rata Skor Lingkungan</p>
          <p className="text-3xl font-bold text-black mt-2">{stats.avgLingkungan}</p>
        </div>
        <div className="border border-[#c9ece7] bg-white/80 backdrop-blur-sm rounded-lg p-6">
          <p className="text-black text-sm font-medium">Rata-rata Kualitas Lingkungan</p>
          <p className="text-3xl font-bold text-black mt-2">{stats.avgKualitas}</p>
        </div>
        <div className="border border-[#c9ece7] bg-white/80 backdrop-blur-sm rounded-lg p-6">
          <p className="text-black text-sm font-medium">Rata-rata Pengelolaan Sampah</p>
          <p className="text-3xl font-bold text-black mt-2">{stats.avgSampah}</p>
        </div>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="border border-[#c9ece7] bg-white/80 backdrop-blur-sm rounded-lg p-6">
          <h2 className="text-lg font-semibold text-black mb-4">Rata-rata Skor Lingkungan per Kabupaten</h2>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={skorLingkunganPerDesa}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e0e0e0" />
              <XAxis dataKey="name" stroke="#666" angle={-45} textAnchor="end" height={80} fontSize={12} />
              <YAxis stroke="#666" />
              <Tooltip contentStyle={{ backgroundColor: "#f5f5f5", border: "1px solid #ccc" }} />
              <Legend />
              <Bar dataKey="skor" fill="#1d2415" name="Skor Lingkungan" />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="border border-[#c9ece7] bg-white/80 backdrop-blur-sm rounded-lg p-6">
          <h2 className="text-lg font-semibold text-black mb-4">Rata-rata Kualitas Lingkungan per Kabupaten</h2>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={kualitasLingkunganPerDesa}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e0e0e0" />
              <XAxis dataKey="name" stroke="#666" angle={-45} textAnchor="end" height={80} fontSize={12} />
              <YAxis stroke="#666" />
              <Tooltip contentStyle={{ backgroundColor: "#f5f5f5", border: "1px solid #ccc" }} />
              <Legend />
              <Bar dataKey="skor" fill="#1d2415" name="Kualitas Lingkungan"/>
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="border border-[#c9ece7] bg-white/80 backdrop-blur-sm rounded-lg p-6">
          <h2 className="text-lg font-semibold text-black mb-4">Rata-rata Komponen Lingkungan (Nasional)</h2>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={komponenLingkunganNasional}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e0e0e0" />
              <XAxis dataKey="name" stroke="#666" />
              <YAxis stroke="#666" />
              <Tooltip contentStyle={{ backgroundColor: "#f5f5f5", border: "1px solid #ccc" }} />
              <Legend />
              <Bar dataKey="avg" fill="#697857" name="Skor Rata-rata" />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="border border-[#c9ece7] bg-white/80 backdrop-blur-sm rounded-lg p-6">
          <h2 className="text-lg font-semibold text-black mb-4">Distribusi Kategori Lingkungan</h2>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={distribusiKategori}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                outerRadius={80}
                fill="#8884d8"
                dataKey="value"
              >
                {distribusiKategori.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </div>

        <div className="border border-[#c9ece7] bg-white/80 backdrop-blur-sm rounded-lg p-6">
          <h2 className="text-lg font-semibold text-black mb-4">Distribusi Kluster Lingkungan</h2>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={distribusiCluster}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                outerRadius={80}
                fill="#8884d8"
                dataKey="value"
              >
                {distribusiCluster.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Tabel Data */}
      <div className="border border-[#c9ece7] bg-white/80 backdrop-blur-sm rounded-lg p-6">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-6">
          <h2 className="text-lg font-semibold text-black">
            Detail Lingkungan Desa ({filteredData.length.toLocaleString()} hasil)
          </h2>
          <input
            type="text"
            placeholder="Cari nama desa, kabupaten, kecamatan, atau label..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="px-4 py-2 border border-[#c9ece7] rounded-lg bg-white text-black placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-[#5fb8a8]"
          />
        </div>

        <div className="overflow-x-auto">
          <table className="w-full border-collapse">
            <thead>
              <tr className="border-b border-[#c9ece7] bg-gray-50">
                <th className="px-4 py-3 text-left text-black font-semibold text-sm">No</th>
                <th className="px-4 py-3 text-left text-black font-semibold text-sm">Kab/Kota</th>
                <th className="px-4 py-3 text-left text-black font-semibold text-sm">Kecamatan</th>
                <th className="px-4 py-3 text-left text-black font-semibold text-sm">Desa</th>
                <th className="px-4 py-3 text-left text-black font-semibold text-sm">Skor Lingkungan</th>
                <th className="px-4 py-3 text-left text-black font-semibold text-sm">Kualitas Lingkungan</th>
                <th className="px-4 py-3 text-left text-black font-semibold text-sm">Pengelolaan Sampah</th>
                <th className="px-4 py-3 text-left text-black font-semibold text-sm">Ketahanan Bencana</th>
                <th className="px-4 py-3 text-left text-black font-semibold text-sm">Kategori</th>
                <th className="px-4 py-3 text-left text-black font-semibold text-sm">Label</th>
              </tr>
            </thead>
            <tbody>
              {paginatedData.length > 0 ? (
                paginatedData.map((item, index) => (
                  <tr key={index} className="border-b border-[#e0e0e0] hover:bg-gray-50 transition-colors">
                    <td className="px-4 py-3 text-black text-sm">{startIndex + index + 1}</td>
                    <td className="px-4 py-3 text-black text-sm">{item.NAMA_KAB}</td>
                    <td className="px-4 py-3 text-black text-sm">{item.NAMA_KEC}</td>
                    <td className="px-4 py-3 text-black font-medium text-sm">{item.NAMA_DESA}</td>
                    <td className="px-4 py-3 text-black text-sm">{item.skor_lingkungan_total.toFixed(1)}</td>
                    <td className="px-4 py-3 text-black text-sm">{item.skor_kualitas_lingkungan.toFixed(1)}</td>
                    <td className="px-4 py-3 text-black text-sm">{item.skor_pengelolaan_sampah.toFixed(1)}</td>
                    <td className="px-4 py-3 text-black text-sm">{item.skor_ketahanan_bencana.toFixed(1)}</td>
                    <td className="px-4 py-3 text-black text-sm">{item.kategori_lingkungan}</td>
                    <td className="px-4 py-3 text-sm">
                      <span className="inline-block px-3 py-1 bg-gray-100 text-gray-800 rounded-full text-xs font-medium">
                        {item.label}
                      </span>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={10} className="px-4 py-6 text-center text-gray-500">
                    Tidak ada data ditemukan
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mt-6 pt-6 border-t border-[#c9ece7]">
          <div className="text-black text-sm">
            Menampilkan {paginatedData.length > 0 ? startIndex + 1 : 0} -{" "}
            {Math.min(endIndex, filteredData.length)} dari {filteredData.length.toLocaleString()} data
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setCurrentPage((prev) => Math.max(prev - 1, 1))}
              disabled={currentPage === 1}
              className="px-4 py-2 border border-[#c9ece7] rounded-lg text-black font-medium disabled:opacity-50 disabled:cursor-not-allowed hover:bg-gray-50 transition-colors"
            >
              Sebelumnya
            </button>

            <div className="flex items-center gap-1">
              <span className="text-black text-sm">Halaman</span>
              <input
                type="number"
                min="1"
                max={totalPages}
                value={currentPage}
                onChange={(e) => {
                  const page = Math.max(1, Math.min(totalPages, Number.parseInt(e.target.value) || 1))
                  setCurrentPage(page)
                }}
                className="w-16 px-2 py-2 border border-[#c9ece7] rounded-lg text-black text-center focus:outline-none focus:ring-2 focus:ring-[#5fb8a8]"
              />
              <span className="text-black text-sm">dari {totalPages}</span>
            </div>

            <button
              onClick={() => setCurrentPage((prev) => Math.min(prev + 1, totalPages))}
              disabled={currentPage === totalPages}
              className="px-4 py-2 border border-[#c9ece7] rounded-lg text-black font-medium disabled:opacity-50 disabled:cursor-not-allowed hover:bg-gray-50 transition-colors"
            >
              Selanjutnya
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}