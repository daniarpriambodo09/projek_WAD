"use client"

import { useEffect, useState } from "react"
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from "recharts"

interface DigitalData {
  NAMA_KAB: string
  NAMA_KEC: string
  NAMA_DESA: string
  jumlah_bts: number
  jumlah_operator: number
  sinyal_telepon: number
  sinyal_internet: number
  ada_warnet: number
  komputer_desa: number
  internet_kantordesa: number
  sid: number
  cluster: number
  label: string
  Latitude : number
  Longitude : number
}

const COLORS = ["#1d2415", "#697857", "#37432b", "#8b907c", "#a8a97a"]
const ITEMS_PER_PAGE = 10

export default function DigitalPage() {
  const [data, setData] = useState<DigitalData[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")
  const [currentPage, setCurrentPage] = useState(1)
  const [filteredData, setFilteredData] = useState<DigitalData[]>([])
  const [totalPages, setTotalPages] = useState(0)
  const [startIndex, setStartIndex] = useState(0)
  const [endIndex, setEndIndex] = useState(0)
  const [paginatedData, setPaginatedData] = useState<DigitalData[]>([])

  // fungsi bantu untuk memecah teks menjadi beberapa baris berdasarkan panjang karakter
  const wrapText = (text: string, maxCharsPerLine = 12) => {
    const words = text.split(" ");
    const lines: string[] = [];
    let currentLine = "";

    words.forEach((word) => {
      const candidate = currentLine ? `${currentLine} ${word}` : word;
      if (candidate.length > maxCharsPerLine) {
        if (currentLine) lines.push(currentLine);
        currentLine = word;
      } else {
        currentLine = candidate;
      }
    });

    if (currentLine) lines.push(currentLine);
    return lines;
  };

  // custom label renderer untuk Pie (menghasilkan <text> dengan beberapa <tspan>)
  const renderCustomLabel = (props: any) => {
    const { cx, cy, midAngle, outerRadius, percent, name } = props;
    const RADIAN = Math.PI / 180;
    const offset = 30; // jarak label dari luar pie, sesuaikan jika perlu
    const radius = outerRadius + offset;
    const x = cx + radius * Math.cos(-midAngle * RADIAN);
    const y = cy + radius * Math.sin(-midAngle * RADIAN);

    const lines = wrapText(String(name), 18); // ubah 12 kalau mau lebih panjang/pendek per baris
    const anchor = x > cx ? "start" : "end";

    return (
      <text
        x={x}
        y={y}
        fill="#12201A"
        textAnchor={anchor}
        dominantBaseline="central"
        fontSize={12}
      >
        {lines.map((line: string, i: number) => (
          <tspan key={i} x={x} dy={i === 0 ? 0 : "1.1em"}>
            {line}
          </tspan>
        ))}
        {/* persentase di baris terakhir */}
        <tspan x={x} dy="1.1em">
          {`${(percent * 100).toFixed(0)}%`}
        </tspan>
      </text>
    );
  };


  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch("http://localhost:8000/api/data_cluster/cluster_digital")
        const result = await response.json()
        setData(result)
      } catch (error) {
        console.error("Error fetching digital data:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchData()
  }, [])

  useEffect(() => {
    const newFilteredData = data.filter(
      (item) =>
        item.NAMA_DESA.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item.NAMA_KEC.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item.NAMA_KAB.toLowerCase().includes(searchTerm.toLowerCase()),
    )
    setFilteredData(newFilteredData)
    setTotalPages(Math.ceil(newFilteredData.length / ITEMS_PER_PAGE))
    setCurrentPage(1)
  }, [data, searchTerm])

  useEffect(() => {
    const newStartIndex = (currentPage - 1) * ITEMS_PER_PAGE
    const newEndIndex = newStartIndex + ITEMS_PER_PAGE
    setStartIndex(newStartIndex)
    setEndIndex(newEndIndex)
    setPaginatedData(filteredData.slice(newStartIndex, newEndIndex))
  }, [currentPage, filteredData])

  if (loading) {
    return <div className="p-8 text-black">Loading...</div>
  }

  const btsOperatorByKabupaten = data
    .reduce(
      (acc, item) => {
        const existing = acc.find((x) => x.name === item.NAMA_KAB)
        if (existing) {
          existing.totalBts += item.jumlah_bts
          existing.totalOperator += item.jumlah_operator
          existing.count += 1
        } else {
          acc.push({
            name: item.NAMA_KAB,
            totalBts: item.jumlah_bts,
            totalOperator: item.jumlah_operator,
            count: 1,
          })
        }
        return acc
      },
      [] as Array<{ name: string; totalBts: number; totalOperator: number; count: number }>,
    )
    .map((item) => ({
      name: item.name,
      bts: Number((item.totalBts / item.count).toFixed(1)),
      operator: Number((item.totalOperator / item.count).toFixed(1)),
    }))

  const signalByKabupaten = data
    .reduce(
      (acc, item) => {
        const existing = acc.find((x) => x.name === item.NAMA_KAB)
        if (existing) {
          existing.totalTelepon += item.sinyal_telepon
          existing.totalInternet += item.sinyal_internet
          existing.count += 1
        } else {
          acc.push({
            name: item.NAMA_KAB,
            totalTelepon: item.sinyal_telepon,
            totalInternet: item.sinyal_internet,
            count: 1,
          })
        }
        return acc
      },
      [] as Array<{ name: string; totalTelepon: number; totalInternet: number; count: number }>,
    )
    .map((item) => ({
      name: item.name,
      telepon: Number((item.totalTelepon / item.count).toFixed(1)),
      internet: Number((item.totalInternet / item.count).toFixed(1)),
    }))

  const digitalInfraChartData = [
    {
      name: "Warnet",
      avg: Number((data.reduce((sum, item) => sum + item.ada_warnet, 0) / data.length).toFixed(1)),
    },
    {
      name: "Komputer Desa",
      avg: Number((data.reduce((sum, item) => sum + item.komputer_desa, 0) / data.length).toFixed(1)),
    },
    {
      name: "Internet Kantor Desa",
      avg: Number((data.reduce((sum, item) => sum + item.internet_kantordesa, 0) / data.length).toFixed(1)),
    },
  ]

  const clusterDistribution = data.reduce(
    (acc, item) => {
      const existing = acc.find((x) => x.name === item.label)
      if (existing) {
        existing.value += 1
      } else {
        acc.push({ name: item.label, value: 1 })
      }
      return acc
    },
    [] as Array<{ name: string; value: number }>,
  )

  // Statistics
  const stats = {
    totalDesa: data.length,
    avgBts: (data.reduce((sum, item) => sum + item.jumlah_bts, 0) / data.length).toFixed(1),
    avgOperator: (data.reduce((sum, item) => sum + item.jumlah_operator, 0) / data.length).toFixed(1),
    avgSinyalInternet: (data.reduce((sum, item) => sum + item.sinyal_internet, 0) / data.length).toFixed(1),
  }

  return (
    <div className="space-y-6 p-8">
      <div>
        <h1 className="text-3xl font-bold text-black mb-2">Analisis Digital Desa</h1>
        <p className="text-gray-600">Data kluster transformasi digital masyarakat per desa</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="border border-[#c9ece7] bg-white/80 backdrop-blur-sm rounded-lg p-6">
          <p className="text-black text-sm font-medium">Total Desa</p>
          <p className="text-3xl font-bold text-black mt-2">{stats.totalDesa}</p>
        </div>
        <div className="border border-[#c9ece7] bg-white/80 backdrop-blur-sm rounded-lg p-6">
          <p className="text-black text-sm font-medium">Rata-rata Jumlah BTS</p>
          <p className="text-3xl font-bold text-black mt-2">{stats.avgBts}</p>
        </div>
        <div className="border border-[#c9ece7] bg-white/80 backdrop-blur-sm rounded-lg p-6">
          <p className="text-black text-sm font-medium">Rata-rata Jumlah Operator</p>
          <p className="text-3xl font-bold text-black mt-2">{stats.avgOperator}</p>
        </div>
        <div className="border border-[#c9ece7] bg-white/80 backdrop-blur-sm rounded-lg p-6">
          <p className="text-black text-sm font-medium">Rata-rata Sinyal Internet</p>
          <p className="text-3xl font-bold text-black mt-2">{stats.avgSinyalInternet}%</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="border border-[#c9ece7] bg-white/80 backdrop-blur-sm rounded-lg p-6">
          <h2 className="text-lg font-semibold text-black mb-4">Rata-rata BTS dan Operator per Kabupaten</h2>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={btsOperatorByKabupaten}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e0e0e0" />
              <XAxis dataKey="name" stroke="#666" angle={-45} textAnchor="end" height={80} fontSize={12} />
              <YAxis stroke="#666" />
              <Tooltip contentStyle={{ backgroundColor: "#f5f5f5", border: "1px solid #ccc" }} />
              <Legend />
              <Bar dataKey="bts" fill="#1d2415" name="BTS" />
              <Bar dataKey="operator" fill="#697857" name="Operator" />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="border border-[#c9ece7] bg-white/80 backdrop-blur-sm rounded-lg p-6">
          <h2 className="text-lg font-semibold text-black mb-4">Kualitas Sinyal per Kabupaten</h2>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={signalByKabupaten}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e0e0e0" />
              <XAxis dataKey="name" stroke="#666" angle={-45} textAnchor="end" height={80} fontSize={12} />
              <YAxis stroke="#666" />
              <Tooltip contentStyle={{ backgroundColor: "#f5f5f5", border: "1px solid #ccc" }} />
              <Legend />
              <Line type="monotone" dataKey="telepon" stroke="#1d2415" strokeWidth={2} name="Sinyal Telepon (%)" />
              <Line type="monotone" dataKey="internet" stroke="#37432b" strokeWidth={2} name="Sinyal Internet (%)" />
            </LineChart>
          </ResponsiveContainer>
        </div>

        <div className="border border-[#c9ece7] bg-white/80 backdrop-blur-sm rounded-lg p-6">
          <h2 className="text-lg font-semibold text-black mb-4">Rata-rata Infrastruktur Digital (Nasional)</h2>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={digitalInfraChartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e0e0e0" />
              <XAxis dataKey="name" stroke="#666" />
              <YAxis stroke="#666" />
              <Tooltip contentStyle={{ backgroundColor: "#f5f5f5", border: "1px solid #ccc" }} />
              <Legend />
              <Bar dataKey="avg" fill="#697857" name="Rata-rata" />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="border border-[#c9ece7] bg-white/80 backdrop-blur-sm rounded-lg p-4">
          <h2 className="text-lg font-semibold text-black mb-4">Distribusi Kluster Digital</h2>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart margin={{ top: 30, right: 60, bottom: 30, left: 60 }}>
              <Pie
                data={clusterDistribution}
                cx="50%"
                cy="50%"
                labelLine={true}
                label={renderCustomLabel} // gunakan custom label
                outerRadius={80}
                fill="#8884d8"
                dataKey="value"
                >
                {clusterDistribution.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>

              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="border border-[#c9ece7] bg-white/80 backdrop-blur-sm rounded-lg p-6">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-6">
          <h2 className="text-lg font-semibold text-black">
            Detail Digital Desa ({filteredData.length.toLocaleString()} hasil)
          </h2>
          <input
            type="text"
            placeholder="Cari nama desa, label, kabupaten, atau kecamatan ..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="px-4 py-2 border border-[#c9ece7] rounded-lg bg-white text-black placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-[#5fb8a8]"
          />
        </div>

        <div className="overflow-x-auto">
          <table className="w-full border-collapse">
            <thead>
              <tr className="border-b border-[#c9ece7] bg-gray-50">
                <th className="px-4 py-3 text-left text-black font-semibold text-sm">No</th>
                <th className="px-4 py-3 text-left text-black font-semibold text-sm">Nama Kab/Kota</th>
                <th className="px-4 py-3 text-left text-black font-semibold text-sm">Nama Kecamatan</th>
                <th className="px-4 py-3 text-left text-black font-semibold text-sm">Nama Desa</th>
                <th className="px-4 py-3 text-left text-black font-semibold text-sm">Jumlah BTS</th>
                <th className="px-4 py-3 text-left text-black font-semibold text-sm">Jumlah Operator</th>
                <th className="px-4 py-3 text-left text-black font-semibold text-sm">Sinyal Telepon</th>
                <th className="px-4 py-3 text-left text-black font-semibold text-sm">Sinyal Internet</th>
                <th className="px-4 py-3 text-left text-black font-semibold text-sm">Warnet</th>
                <th className="px-4 py-3 text-left text-black font-semibold text-sm">Komputer Desa</th>
                <th className="px-4 py-3 text-left text-black font-semibold text-sm">Internet Kantor</th>
                <th className="px-4 py-3 text-left text-black font-semibold text-sm">Label</th>
              </tr>
            </thead>
            <tbody>
              {paginatedData.length > 0 ? (
                paginatedData.map((item, index) => (
                  <tr key={index} className="border-b border-[#e0e0e0] hover:bg-gray-50 transition-colors">
                    <td className="px-4 py-3 text-black text-sm">{startIndex + index + 1}</td>
                    <td className="px-4 py-3 text-black text-sm">{item.NAMA_KAB}</td>
                    <td className="px-4 py-3 text-black text-sm">{item.NAMA_KEC}</td>
                    <td className="px-4 py-3 text-black font-medium text-sm">{item.NAMA_DESA}</td>
                    <td className="px-4 py-3 text-black text-sm text-center">{item.jumlah_bts}</td>
                    <td className="px-4 py-3 text-black text-sm text-center">{item.jumlah_operator}</td>
                    <td className="px-4 py-3 text-black text-sm text-center">{item.sinyal_telepon}%</td>
                    <td className="px-4 py-3 text-black text-sm text-center">{item.sinyal_internet}%</td>
                    <td className="px-4 py-3 text-black text-sm text-center">{item.ada_warnet}</td>
                    <td className="px-4 py-3 text-black text-sm text-center">{item.komputer_desa}</td>
                    <td className="px-4 py-3 text-black text-sm text-center">{item.internet_kantordesa}</td>
                    <td className="px-4 py-3 text-sm">
                      <span className="inline-block px-3 py-1 bg-gray-100 text-gray-800 rounded-full text-xs font-medium">
                        {item.label}
                      </span>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={12} className="px-4 py-6 text-center text-gray-500">
                    Tidak ada data ditemukan
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mt-6 pt-6 border-t border-[#c9ece7]">
          <div className="text-black text-sm">
            Menampilkan {paginatedData.length > 0 ? startIndex + 1 : 0} - {Math.min(endIndex, filteredData.length)} dari{" "}
            {filteredData.length.toLocaleString()} data
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setCurrentPage((prev) => Math.max(prev - 1, 1))}
              disabled={currentPage === 1}
              className="px-4 py-2 border border-[#c9ece7] rounded-lg text-black font-medium disabled:opacity-50 disabled:cursor-not-allowed hover:bg-gray-50 transition-colors"
            >
              Sebelumnya
            </button>

            <div className="flex items-center gap-1">
              <span className="text-black text-sm">Halaman</span>
              <input
                type="number"
                min="1"
                max={totalPages}
                value={currentPage}
                onChange={(e) => {
                  const page = Math.max(1, Math.min(totalPages, Number.parseInt(e.target.value) || 1))
                  setCurrentPage(page)
                }}
                className="w-16 px-2 py-2 border border-[#c9ece7] rounded-lg text-black text-center focus:outline-none focus:ring-2 focus:ring-[#5fb8a8]"
              />
              <span className="text-black text-sm">dari {totalPages}</span>
            </div>

            <button
              onClick={() => setCurrentPage((prev) => Math.min(prev + 1, totalPages))}
              disabled={currentPage === totalPages}
              className="px-4 py-2 border border-[#c9ece7] rounded-lg text-black font-medium disabled:opacity-50 disabled:cursor-not-allowed hover:bg-gray-50 transition-colors"
            >
              Selanjutnya
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}
