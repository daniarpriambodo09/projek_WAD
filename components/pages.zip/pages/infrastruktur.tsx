"use client"

import { useState, useEffect } from "react"
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from "recharts"
import dynamic from "next/dynamic"

interface VillageData {
  kk_pln: number
  kk_non_pln: number
  kk_tanpa_listrik: number
  total_kk: number
  penerangan_jalan: number
  air_minum_aman: number
  air_cuci_bersih: number
  sanitasi_layak: number
  irigasi: number
  jalan_aspal: number
  skor_listrik: number
  skor_sanitasi: number
  skor_air: number
  skor_transportasi: number
  skor_digital: number
  skor_aksesibilitas: number
  cluster: number
  label_infrastruktur: string
  NAMA_KAB: string
  NAMA_KEC: string
  NAMA_DESA: string
  Longitude : number
  Latitude : number
}
const MapComponent = dynamic(() => import("./MapComponent"), {
  ssr: false,
  loading: () => (
    <div className="h-96 bg-white/80 backdrop-blur-sm rounded-lg animate-pulse" />
  ),
})

const COLORS = ["#1d2415", "#697857", "#37432b", "#8b907c", "#a8a97a"]
const ITEMS_PER_PAGE = 10

export default function Infrastruktur() {
  const [searchTerm, setSearchTerm] = useState("")
  const [villageData, setVillageData] = useState<VillageData[]>([])
  const [loading, setLoading] = useState(true)
  const [currentPage, setCurrentPage] = useState(1)
  const [filteredData, setFilteredData] = useState<VillageData[]>([])
  const [totalPages, setTotalPages] = useState(0)
  const itemsPerPage = 10

  // Filter State
    const [selectedKab, setSelectedKab] = useState<string>("")
    const [selectedKec, setSelectedKec] = useState<string>("")
    const [selectedDesa, setSelectedDesa] = useState<string>("")
    const [kecamatanOptions, setKecamatanOptions] = useState<string[]>([])
    const [desaOptions, setDesaOptions] = useState<string[]>([])
    const [chartDataForKecamatan, setChartDataForKecamatan] = useState<VillageData[]>([])
  
    // Efek untuk data chart (hanya kab & kec)
    useEffect(() => {
      let newChartData = villageData.filter(
        (item) =>
          item.NAMA_KAB === selectedKab && item.NAMA_KEC === selectedKec
      )
      setChartDataForKecamatan(newChartData)
    }, [villageData, selectedKab, selectedKec])
  
    // Update kecamatan options saat kabupaten berubah
    useEffect(() => {
      if (selectedKab) {
        const kecList = [...new Set(villageData.filter(d => d.NAMA_KAB === selectedKab).map(d => d.NAMA_KEC))]
        setKecamatanOptions(kecList)
        setSelectedKec("")
        setSelectedDesa("")
      } else {
        setKecamatanOptions([])
        setSelectedKec("")
        setSelectedDesa("")
      }
    }, [selectedKab, villageData])
  
    // Update desa options saat kecamatan berubah
    useEffect(() => {
      if (selectedKec && selectedKab) {
        const desaList = [...new Set(villageData.filter(d => d.NAMA_KEC === selectedKec && d.NAMA_KAB === selectedKab).map(d => d.NAMA_DESA))]
        setDesaOptions(desaList)
        setSelectedDesa("")
      } else {
        setDesaOptions([])
        setSelectedDesa("")
      }
    }, [selectedKec, selectedKab, villageData])
  
    // Filter data berdasarkan pencarian dan dropdown
    useEffect(() => {
      let newFilteredData = villageData.filter(
        (item) =>
          item.NAMA_DESA.toLowerCase().includes(searchTerm.toLowerCase()) ||
          item.NAMA_KEC.toLowerCase().includes(searchTerm.toLowerCase()) ||
          item.NAMA_KAB.toLowerCase().includes(searchTerm.toLowerCase()) ||
          item.label_infrastruktur.toLowerCase().includes(searchTerm.toLowerCase())
      )
  
      if (selectedKab) newFilteredData = newFilteredData.filter(item => item.NAMA_KAB === selectedKab)
      if (selectedKec) newFilteredData = newFilteredData.filter(item => item.NAMA_KEC === selectedKec)
      if (selectedDesa) newFilteredData = newFilteredData.filter(item => item.NAMA_DESA === selectedDesa)
  
      setFilteredData(newFilteredData)
      setTotalPages(Math.ceil(newFilteredData.length / ITEMS_PER_PAGE))
      setCurrentPage(1)
    }, [villageData, searchTerm, selectedKab, selectedKec, selectedDesa])

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch("http://localhost:8000/api/data_cluster/cluster_infrastruktur")
        const data = await response.json()
        setVillageData(data)
      } catch (error) {
        console.log("[v0] Error fetching data:", error)
        setVillageData([])
      } finally {
        setLoading(false)
      }
    }

    fetchData()
  }, [])

  const allFilteredData = villageData.filter((row) => {
    const searchLower = searchTerm.toLowerCase()
    return (
      row.NAMA_DESA.toLowerCase().includes(searchLower) ||
      row.label_infrastruktur.toLowerCase().includes(searchLower) ||
      row.NAMA_KAB.toLowerCase().includes(searchLower) ||
      row.NAMA_KEC.toLowerCase().includes(searchLower)
    )
  })

  const startIndex = (currentPage - 1) * itemsPerPage
  const endIndex = startIndex + itemsPerPage
  const paginatedData = allFilteredData.slice(startIndex, endIndex)

  const clusterDistribution = filteredData.reduce(
    (acc, item) => {
      const existing = acc.find(x => x.name === item.label_infrastruktur)
      if (existing) {
        existing.value += 1
      } else {
        acc.push({ name: item.label_infrastruktur, value: 1 })
      }
      return acc
    },
    [] as Array<{ name: string; value: number }>
  )
  const avgScores = {
    listrik: (villageData.reduce((sum, row) => sum + row.skor_listrik, 0) / villageData.length).toFixed(1),
    sanitasi: (villageData.reduce((sum, row) => sum + row.skor_sanitasi, 0) / villageData.length).toFixed(1),
    air: (villageData.reduce((sum, row) => sum + row.skor_air, 0) / villageData.length).toFixed(1),
    transportasi: (villageData.reduce((sum, row) => sum + row.skor_transportasi, 0) / villageData.length).toFixed(1),
    digital: (villageData.reduce((sum, row) => sum + row.skor_digital, 0) / villageData.length).toFixed(1),
    aksesibilitas: (villageData.reduce((sum, row) => sum + row.skor_aksesibilitas, 0) / villageData.length).toFixed(1),
  }

  const scoreData = [
    { name: "Listrik", skor: Number.parseFloat(avgScores.listrik) },
    { name: "Sanitasi", skor: Number.parseFloat(avgScores.sanitasi) },
    { name: "Air", skor: Number.parseFloat(avgScores.air) },
    { name: "Transportasi", skor: Number.parseFloat(avgScores.transportasi) },
    { name: "Digital", skor: Number.parseFloat(avgScores.digital) },
    { name: "Aksesibilitas", skor: Number.parseFloat(avgScores.aksesibilitas) },
  ]

  // ✅ Prepare markers for map
  const mapMarkers = chartDataForKecamatan
    .filter(item => item.Latitude != null && item.Longitude != null)
    .map(item => ({
      name: `${item.NAMA_DESA}, ${item.NAMA_KEC}`,
      position: [item.Latitude, item.Longitude] as [number, number],
    }))


  const COLORS = ["#324D3E", "#728A6E", "#8EA48B", "#B3C8A1", "#C9D9C3"]

  if (loading) {
    return <div className="text-center py-8">Loading data...</div>
  }

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-black mb-2">Analisis Infrastruktur</h1>
          <p className="text-gray-600">Data clustering infrastruktur desa dengan machine learning</p>
        </div>
        {/* Filter Kabupaten */}
        <div className="flex gap-3 flex-wrap justify-end">
          <div className="flex flex-col gap-1">
            <label className="text-xs font-bold text-muted-foreground">Filter Kabupaten</label>
            <select 
              value={selectedKab}
              onChange={(e) => setSelectedKab(e.target.value)}
              className="px-3 py-2 bg-white border border-border rounded-md text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
            >
              <option value="">Semua Kabupaten</option>
              {[...new Set(villageData.map(d => d.NAMA_KAB))].map(kab => (
                <option key={kab} value={kab}>{kab}</option>
              ))}
            </select>
          </div>

          <div className="flex flex-col gap-1">
            <label className="text-xs font-bold text-muted-foreground">Filter Kecamatan</label>
            <select 
              value={selectedKec}
              onChange={(e) => setSelectedKec(e.target.value)}
              className="px-3 py-2 bg-white border border-border rounded-md text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
              disabled={!selectedKab}
            >
              <option value="">Semua Kecamatan</option>
              {kecamatanOptions.map(kec => (
                <option key={kec} value={kec}>{kec}</option>
              ))}
            </select>
          </div>

          <div className="flex flex-col gap-1">
            <label className="text-xs font-bold text-muted-foreground">Filter Desa</label>
            <select 
              value={selectedDesa}
              onChange={(e) => setSelectedDesa(e.target.value)}
              className="px-3 py-2 bg-white border border-border rounded-md text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
              disabled={!selectedKec}
            >
              <option value="">Semua Desa</option>
              {desaOptions.map(desa => (
                <option key={desa} value={desa}>{desa}</option>
              ))}
            </select>
          </div>
        </div>
      </div>
      

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white/80 backdrop-blur-sm border border-[#c9ece7] rounded-xl p-6">
          <p className="text-gray-800 text-sm">Total Data Desa</p>
          <p className="text-3xl font-bold text-black mt-2">{villageData.length}</p>
        </div>
        <div className="bg-white/80 backdrop-blur-sm border border-[#c9ece7] rounded-xl p-6">
          <p className="text-gray-800 text-sm">Rata-rata Skor Listrik</p>
          <p className="text-3xl font-bold text-black mt-2">{avgScores.listrik}</p>
        </div>
        <div className="bg-white/80 backdrop-blur-sm border border-[#c9ece7] rounded-xl p-6">
          <p className="text-gray-800 text-sm">Rata-rata Skor Sanitasi</p>
          <p className="text-3xl font-bold text-black mt-2">{avgScores.sanitasi}</p>
        </div>
      </div>

      {/* Map - Updated to use filtered markers */}
      <div className="bg-white/80 backdrop-blur-sm border border-[#c9ece7] rounded-lg overflow-hidden">
        <h2 className="text-lg font-semibold text-black p-3 pb-2">Sebaran Desa di Jawa Timur</h2>
        <div className="h-96 w-full">
          <MapComponent markers={mapMarkers} />
        </div>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white/80 backdrop-blur-sm border border-[#c9ece7] rounded-xl p-6">
          <h2 className="text-lg font-semibold text-black mb-4">Distribusi Cluster Infrastruktur</h2>
          <div className="flex flex-col items-center">
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={clusterDistribution}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {clusterDistribution.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip
                  formatter={(value, name, props) => {
                    if (name === "value") {
                      return [`${value} desa (${props.payload.percentage}%)`, "Jumlah"]
                    }
                    return [value, name]
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white/80 backdrop-blur-sm border border-[#c9ece7] rounded-xl p-6">
          <h2 className="text-lg font-semibold text-black mb-4">Rata-rata Skor Infrastruktur</h2>
          <ResponsiveContainer width="100%" height={350}>
            <BarChart data={scoreData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e0e0e0" />
              <XAxis dataKey="name" stroke="#666" fontSize={12} />
              <YAxis stroke="#666" fontSize={12} />
              <Tooltip contentStyle={{ backgroundColor: "#fff", border: "1px solid #ccc", borderRadius: "4px" }} />
              <Bar dataKey="skor" fill="#324D3E" radius={[8, 8, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Table */}
      <div className="border border-[#c9ece7] bg-white/80 backdrop-blur-sm rounded-lg p-6">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-6">
          <h2 className="text-lg font-semibold text-black mb-4">Detail Infrastruktur per Desa</h2>
          <input
            type="text"
            placeholder="Cari nama desa, label, kabupaten, atau kecamatan..."
            value={searchTerm}
            onChange={(e) => {
              setSearchTerm(e.target.value)
              setCurrentPage(1)
            }}
            className="px-4 py-2 border border-[#c9ece7] rounded-lg bg-white text-black placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-[#5fb8a8]"
          />
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b-2 border-gray-400 bg-gray-50">
                <th className="text-center py-4 px-4 text-black font-semibold text-sm">No</th>
                <th className="text-left py-4 px-4 text-black font-semibold text-sm">Nama Kab/Kota</th> 
                <th className="text-left py-4 px-4 text-black font-semibold text-sm">Nama Kecamatan</th> 
                <th className="text-left py-4 px-4 text-black font-semibold text-sm">Nama Desa</th>
                <th className="text-center py-4 px-4 text-black font-semibold text-sm">Listrik</th>
                <th className="text-center py-4 px-4 text-black font-semibold text-sm">Sanitasi</th>
                <th className="text-center py-4 px-4 text-black font-semibold text-sm">Air</th>
                <th className="text-center py-4 px-4 text-black font-semibold text-sm">Transportasi</th>
                <th className="text-center py-4 px-4 text-black font-semibold text-sm">Digital</th>
                <th className="text-center py-4 px-4 text-black font-semibold text-sm">Aksesibilitas</th>
                <th className="text-center py-4 px-4 text-black font-semibold text-sm">Label</th>
              </tr>
            </thead>
            <tbody>
              {paginatedData.length > 0 ? (
                paginatedData.map((row, idx) => (
                  <tr key={idx} className="border-b border-gray-300 hover:bg-gray-50 transition-colors">
                    <td className="py-4 px-4 text-center text-black font-medium text-sm">{startIndex + idx + 1}</td>
                    <td className="py-4 px-4 text-black text-sm">{row.NAMA_KAB}</td>
                    <td className="py-4 px-4 text-black text-sm">{row.NAMA_KEC}</td>
                    <td className="py-4 px-4 text-black text-sm">{row.NAMA_DESA}</td>
                    <td className="py-4 px-4 text-center text-black text-sm">{row.skor_listrik.toFixed(1)}</td>
                    <td className="py-4 px-4 text-center text-black text-sm">{row.skor_sanitasi.toFixed(1)}</td>
                    <td className="py-4 px-4 text-center text-black text-sm">{row.skor_air.toFixed(1)}</td>
                    <td className="py-4 px-4 text-center text-black text-sm">{row.skor_transportasi.toFixed(1)}</td>
                    <td className="py-4 px-4 text-center text-black text-sm">{row.skor_digital.toFixed(1)}</td>
                    <td className="py-4 px-4 text-center text-black text-sm">{row.skor_aksesibilitas.toFixed(1)}</td>
                    <td className="py-3 px-4">
                      <span className={`inline-block px-4 py-1 rounded-full text-xs font-medium ${
                        row.cluster === 0
                          ? "bg-green-900 text-green-200"
                          : row.cluster === 1
                            ? "bg-yellow-900 text-yellow-200"
                            : "bg-red-900 text-red-200"
                      }`}
                      >
                        {row.label_infrastruktur}
                      </span>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={9} className="py-6 px-4 text-center text-gray-500 text-sm">
                    Tidak ada data yang cocok dengan pencarian "{searchTerm}"
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        <div className="mt-6 flex items-center justify-between">
          <div className="text-sm text-gray-600">
            Menampilkan {paginatedData.length > 0 ? startIndex + 1 : 0} hingga{" "}
            {Math.min(endIndex, allFilteredData.length)} dari {allFilteredData.length} data
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
              disabled={currentPage === 1}
              className="px-3 py-2 border border-gray-300 rounded-lg text-black text-sm disabled:opacity-50 disabled:cursor-not-allowed hover:bg-gray-100"
            >
              Sebelumnya
            </button>
            <div className="flex items-center gap-1">
              {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                let pageNum
                if (totalPages <= 5) {
                  pageNum = i + 1
                } else if (currentPage <= 3) {
                  pageNum = i + 1
                } else if (currentPage >= totalPages - 2) {
                  pageNum = totalPages - 4 + i
                } else {
                  pageNum = currentPage - 2 + i
                }
                return (
                  <button
                    key={pageNum}
                    onClick={() => setCurrentPage(pageNum)}
                    className={`px-3 py-2 rounded-lg text-sm ${
                      currentPage === pageNum
                        ? "bg-green-600 text-white"
                        : "border border-gray-300 text-black hover:bg-gray-100"
                    }`}
                  >
                    {pageNum}
                  </button>
                )
              })}
            </div>
            <button
              onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))}
              disabled={currentPage === totalPages}
              className="px-3 py-2 border border-gray-300 rounded-lg text-black text-sm disabled:opacity-50 disabled:cursor-not-allowed hover:bg-gray-100"
            >
              Selanjutnya
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}
