// src/app/(your-path)/ekonomi.tsx
"use client"

import dynamic from "next/dynamic"
import { useEffect, useState, useMemo } from "react"
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from "recharts"

interface EkonomiData {
  NAMA_KAB: string
  NAMA_KEC: string
  NAMA_DESA: string
  total_kk: number
  total_penduduk: number
  sktm: number
  skor_kesejahteraan: number
  sektor_dominan: number
  grup_sektor: string
  sektor_pertanian: number
  sektor_perdagangan: number
  sektor_industri: number
  sektor_jasa: number
  sektor_lainnya: number
  ada_pades: number
  jumlah_bumdes: number
  skor_bumdes: number
  jumlah_koperasi: number
  skor_koperasi: number
  ada_produk_unggulan: number
  total_industri: number
  skor_industri: number
  skor_akses_modal: number
  skor_infrastruktur_ekonomi: number
  skor_ekonomi_total: number
  kategori_ekonomi: string
  cluster: number
  label: string
  Latitude: number
  Longitude: number
}

const MapComponent = dynamic(() => import("./MapComponent"), {
  ssr: false,
  loading: () => (
    <div className="h-96 bg-white/80 backdrop-blur-sm rounded-lg animate-pulse" />
  ),
})

const COLORS = ["#1d2415", "#697857", "#37432b", "#8b907c", "#a8a97a"]
const ITEMS_PER_PAGE = 10

export default function EkonomiPage() {
  const [data, setData] = useState<EkonomiData[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")
  const [currentPage, setCurrentPage] = useState(1)
  const [filteredData, setFilteredData] = useState<EkonomiData[]>([])
  const [totalPages, setTotalPages] = useState(0)
  const [startIndex, setStartIndex] = useState(0)
  const [endIndex, setEndIndex] = useState(0)
  const [paginatedData, setPaginatedData] = useState<EkonomiData[]>([])

  const [selectedKab, setSelectedKab] = useState<string>("")
  const [selectedKec, setSelectedKec] = useState<string>("")
  const [selectedDesa, setSelectedDesa] = useState<string>("")
  const [kecamatanOptions, setKecamatanOptions] = useState<string[]>([])
  const [desaOptions, setDesaOptions] = useState<string[]>([])
  const [chartDataForKecamatan, setChartDataForKecamatan] = useState<EkonomiData[]>([])

  // Fetch data
  useEffect(() => {
    const controller = new AbortController()
    const fetchData = async () => {
      try {
        const response = await fetch("http://localhost:8000/api/data_cluster/cluster_ekonomi", {
          signal: controller.signal,
        })
        const result = await response.json()
        if (Array.isArray(result)) setData(result)
      } catch (error) {
        if (!(error instanceof DOMException && error.name === "AbortError")) {
          console.error("Error fetching data:", error)
        }
      } finally {
        setLoading(false)
      }
    }
    fetchData()
    return () => controller.abort()
  }, [])

  // Update chartDataForKecamatan
  useEffect(() => {
    setChartDataForKecamatan(
      data.filter(item => item.NAMA_KAB === selectedKab && item.NAMA_KEC === selectedKec)
    )
  }, [data, selectedKab, selectedKec])

  // Update kecamatan options
  useEffect(() => {
    if (selectedKab) {
      const kecs = [...new Set(data.filter(d => d.NAMA_KAB === selectedKab).map(d => d.NAMA_KEC))]
      setKecamatanOptions(kecs)
      setSelectedKec("")
      setSelectedDesa("")
    } else {
      setKecamatanOptions([])
      setSelectedKec("")
      setSelectedDesa("")
    }
  }, [selectedKab, data])

  // Update desa options
  useEffect(() => {
    if (selectedKab && selectedKec) {
      const desas = [...new Set(
        data.filter(d => d.NAMA_KAB === selectedKab && d.NAMA_KEC === selectedKec).map(d => d.NAMA_DESA)
      )]
      setDesaOptions(desas)
      setSelectedDesa("")
    } else {
      setDesaOptions([])
      setSelectedDesa("")
    }
  }, [selectedKab, selectedKec, data])

  // Filter & search
  useEffect(() => {
    let result = data.filter(
      item =>
        item.NAMA_DESA.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item.NAMA_KEC.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item.NAMA_KAB.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item.label.toLowerCase().includes(searchTerm.toLowerCase())
    )
    if (selectedKab) result = result.filter(item => item.NAMA_KAB === selectedKab)
    if (selectedKec) result = result.filter(item => item.NAMA_KEC === selectedKec)
    if (selectedDesa) result = result.filter(item => item.NAMA_DESA === selectedDesa)

    setFilteredData(result)
    setTotalPages(Math.ceil(result.length / ITEMS_PER_PAGE))
    setCurrentPage(1)
  }, [data, searchTerm, selectedKab, selectedKec, selectedDesa])

  // Pagination
  useEffect(() => {
    const start = (currentPage - 1) * ITEMS_PER_PAGE
    const end = start + ITEMS_PER_PAGE
    setStartIndex(start)
    setEndIndex(end)
    setPaginatedData(chartDataForKecamatan.slice(start, end))
  }, [currentPage, chartDataForKecamatan])

  // Charts
  const desaChartData = useMemo(() =>
    chartDataForKecamatan.map(item => ({
      name: item.NAMA_DESA,
      skor: Number(item.skor_ekonomi_total.toFixed(1)),
    })).sort((a, b) => b.skor - a.skor),
    [chartDataForKecamatan]
  )

  const kesejahteraanByDesa = useMemo(() =>
    chartDataForKecamatan.map(item => ({
      name: item.NAMA_DESA,
      skor: Number(item.skor_kesejahteraan.toFixed(1)),
    })).sort((a, b) => b.skor - a.skor),
    [chartDataForKecamatan]
  )

  const sectorChartData = useMemo(() => {
    if (filteredData.length === 0) return []
    const avg = (key: keyof EkonomiData) => {
      const sum = filteredData.reduce((acc, item) => acc + (Number(item[key]) || 0), 0)
      return Number((sum / filteredData.length).toFixed(1))
    }
    return [
      { name: "Pertanian", avg: avg("sektor_pertanian") },
      { name: "Perdagangan", avg: avg("sektor_perdagangan") },
      { name: "Industri", avg: avg("sektor_industri") },
      { name: "Lainnya", avg: avg("sektor_lainnya") },
    ]
  }, [filteredData])

  const komponenEkonomiData = useMemo(() => {
    if (filteredData.length === 0) return []
    const avg = (key: keyof EkonomiData) => {
      const sum = filteredData.reduce((acc, item) => acc + (Number(item[key]) || 0), 0)
      return Number((sum / filteredData.length).toFixed(1))
    }
    return [
      { name: "BUMDES", avg: avg("skor_bumdes") },
      { name: "Koperasi", avg: avg("skor_koperasi") },
      { name: "Industri", avg: avg("skor_industri") },
      { name: "Akses Modal", avg: avg("skor_akses_modal") },
    ]
  }, [filteredData])

  const infrastrukturEkonomiData = useMemo(() => {
    if (filteredData.length === 0) return []
    return [{
      name: "Infrastruktur Ekonomi",
      avg: Number(
        (filteredData.reduce((sum, item) => sum + item.skor_infrastruktur_ekonomi, 0) / filteredData.length).toFixed(1)
      )
    }]
  }, [filteredData])

  const clusterDistribution = useMemo(() => {
    return chartDataForKecamatan.reduce(
      (acc, item) => {
        const existing = acc.find(x => x.name === item.label)
        if (existing) existing.value += 1
        else acc.push({ name: item.label, value: 1 })
        return acc
      },
      [] as Array<{ name: string; value: number }>
    )
  }, [chartDataForKecamatan])

  const stats = useMemo(() => ({
    totalDesa: chartDataForKecamatan.length,
    avgEkonomi: filteredData.length > 0
      ? (filteredData.reduce((sum, item) => sum + item.skor_ekonomi_total, 0) / filteredData.length).toFixed(1)
      : "0.0",
    avgKesejahteraan: filteredData.length > 0
      ? (filteredData.reduce((sum, item) => sum + item.skor_kesejahteraan, 0) / filteredData.length).toFixed(1)
      : "0.0",
    avgBUMDES: filteredData.length > 0
      ? (filteredData.reduce((sum, item) => sum + item.jumlah_bumdes, 0) / filteredData.length).toFixed(1)
      : "0.0",
  }), [filteredData])

  // ✅ Kirim cluster dan label ke peta
  const mapMarkers = useMemo(() =>
    chartDataForKecamatan
      .filter(m => !isNaN(m.Latitude) && !isNaN(m.Longitude))
      .map(m => ({
        name: m.NAMA_DESA,
        position: [m.Latitude, m.Longitude] as [number, number],
        kabupaten: m.NAMA_KAB,
        kecamatan: m.NAMA_KEC,
        skorEkonomi: m.skor_ekonomi_total,
        skorKesejahteraan: m.skor_kesejahteraan,
        cluster: m.cluster,
        label: m.label, // ✅ penting untuk legend
      })),
    [chartDataForKecamatan]
  )

  if (loading) {
    return <div className="p-8 text-black">Loading...</div>
  }

  return (
    <div className="space-y-6 p-8">
      {/* Header */}
      <div className="flex items-start justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-black mb-2">Analisis Ekonomi Desa</h1>
          <p className="text-gray-600">Data kluster ekonomi dan usaha per desa</p>
        </div>
        <div className="flex gap-3 flex-wrap justify-end">
          <div className="flex flex-col gap-1">
            <label className="text-xs font-bold text-gray-600">Filter Kabupaten</label>
            <select
              value={selectedKab}
              onChange={(e) => setSelectedKab(e.target.value)}
              className="px-3 py-2 bg-white border border-[#c9ece7] rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-[#5fb8a8]"
            >
              <option value="">Semua Kabupaten</option>
              {[...new Set(data.map(d => d.NAMA_KAB))].map(kab => (
                <option key={kab} value={kab}>{kab}</option>
              ))}
            </select>
          </div>

          <div className="flex flex-col gap-1">
            <label className="text-xs font-bold text-gray-600">Filter Kecamatan</label>
            <select
              value={selectedKec}
              onChange={(e) => setSelectedKec(e.target.value)}
              className="px-3 py-2 bg-white border border-[#c9ece7] rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-[#5fb8a8]"
              disabled={!selectedKab}
            >
              <option value="">Semua Kecamatan</option>
              {kecamatanOptions.map(kec => (
                <option key={kec} value={kec}>{kec}</option>
              ))}
            </select>
          </div>

          <div className="flex flex-col gap-1">
            <label className="text-xs font-bold text-gray-600">Filter Desa</label>
            <select
              value={selectedDesa}
              onChange={(e) => setSelectedDesa(e.target.value)}
              className="px-3 py-2 bg-white border border-[#c9ece7] rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-[#5fb8a8]"
              disabled={!selectedKec}
            >
              <option value="">Semua Desa</option>
              {desaOptions.map(desa => (
                <option key={desa} value={desa}>{desa}</option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="border border-[#c9ece7] bg-white/80 backdrop-blur-sm rounded-lg p-6">
          <p className="text-black text-sm font-medium">Total Desa per Kecamatan</p>
          <p className="text-3xl font-bold text-black mt-2">{stats.totalDesa}</p>
        </div>
        <div className="border border-[#c9ece7] bg-white/80 backdrop-blur-sm rounded-lg p-6">
          <p className="text-black text-sm font-medium">Rata-rata Skor Ekonomi</p>
          <p className="text-3xl font-bold text-black mt-2">{stats.avgEkonomi}</p>
        </div>
        <div className="border border-[#c9ece7] bg-white/80 backdrop-blur-sm rounded-lg p-6">
          <p className="text-black text-sm font-medium">Rata-rata Kesejahteraan</p>
          <p className="text-3xl font-bold text-black mt-2">{stats.avgKesejahteraan}</p>
        </div>
        <div className="border border-[#c9ece7] bg-white/80 backdrop-blur-sm rounded-lg p-6">
          <p className="text-black text-sm font-medium">Rata-rata BUMDES</p>
          <p className="text-3xl font-bold text-black mt-2">{stats.avgBUMDES}</p>
        </div>
      </div>

      {/* Map */}
      <div className="border border-[#c9ece7] rounded-lg bg-white/80 backdrop-blur-sm overflow-hidden">
        <h2 className="p-3 font-semibold text-black">Sebaran Desa ({mapMarkers.length} desa)</h2>
        <div className="h-96 w-full">
          <MapComponent
            markers={mapMarkers}
            renderTooltip={(marker) => (
              <>
                <div className="font-semibold">{marker.name}</div>
                {marker.kecamatan && <div>Kec. {marker.kecamatan}</div>}
                {marker.kabupaten && <div>Kab. {marker.kabupaten}</div>}
                {marker.skorEkonomi !== undefined && (
                  <div>Skor Ekonomi: {marker.skorEkonomi.toFixed(1)}</div>
                )}
                {marker.label && <div>{marker.label}</div>}
              </>
            )}
          />
        </div>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Chart 1 */}
        <div className="border border-[#c9ece7] bg-white/80 backdrop-blur-sm rounded-lg p-6">
          <h2 className="text-lg font-semibold text-black mb-4">
            Skor Ekonomi per Desa ({chartDataForKecamatan.length} desa di {selectedKec || "Semua"})
          </h2>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={desaChartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e0e0e0" />
              <XAxis dataKey="name" stroke="#666" angle={-45} textAnchor="end" height={80} fontSize={12} />
              <YAxis stroke="#666" />
              <Tooltip />
              <Bar dataKey="skor" fill="#1d2415" name="Skor Ekonomi" />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Chart 2 */}
        <div className="border border-[#c9ece7] bg-white/80 backdrop-blur-sm rounded-lg p-6">
          <h2 className="text-lg font-semibold text-black mb-4">
            Skor Kesejahteraan per Desa
          </h2>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={kesejahteraanByDesa} layout="vertical" margin={{ left: 120 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e0e0e0" />
              <XAxis type="number" stroke="#666" />
              <YAxis dataKey="name" type="category" stroke="#666" fontSize={11} />
              <Tooltip />
              <Bar dataKey="skor" fill="#1d2415" name="Skor Kesejahteraan" />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Chart 3 */}
        <div className="border border-[#c9ece7] bg-white/80 backdrop-blur-sm rounded-lg p-6">
          <h2 className="text-lg font-semibold text-black mb-4">Sektor Ekonomi (Rata-rata)</h2>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart layout="vertical" data={sectorChartData} margin={{ left: 120 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e0e0e0" />
              <XAxis type="number" stroke="#666" />
              <YAxis dataKey="name" type="category" stroke="#666" />
              <Tooltip />
              <Bar dataKey="avg" fill="#697857" name="Rata-rata" />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Chart 4 */}
        <div className="border border-[#c9ece7] bg-white/80 backdrop-blur-sm rounded-lg p-6">
          <h2 className="text-lg font-semibold text-black mb-4">Skor Komponen Ekonomi</h2>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={komponenEkonomiData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e0e0e0" />
              <XAxis dataKey="name" stroke="#666" />
              <YAxis stroke="#666" />
              <Tooltip />
              <Bar dataKey="avg" fill="#37432b" name="Rata-rata" />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Chart 5 */}
        <div className="border border-[#c9ece7] bg-white/80 backdrop-blur-sm rounded-lg p-6">
          <h2 className="text-lg font-semibold text-black mb-4">Infrastruktur Ekonomi (Rata-rata)</h2>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={infrastrukturEkonomiData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e0e0e0" />
              <XAxis dataKey="name" stroke="#666" />
              <YAxis stroke="#666" />
              <Tooltip />
              <Bar dataKey="avg" fill="#8b907c" name="Skor" />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Chart 6 */}
        <div className="border border-[#c9ece7] bg-white/80 backdrop-blur-sm rounded-lg p-6">
          <h2 className="text-lg font-semibold text-black mb-4">Distribusi Kluster Ekonomi</h2>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={clusterDistribution}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                outerRadius={80}
                dataKey="value"
              >
                {clusterDistribution.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Table & Pagination */}
      <div className="border border-[#c9ece7] bg-white/80 backdrop-blur-sm rounded-lg p-6">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-6">
          <h2 className="text-lg font-semibold text-black">
            Detail Ekonomi Desa ({filteredData.length.toLocaleString()} hasil)
          </h2>
          <input
            type="text"
            placeholder="Cari nama desa, label, kabupaten, atau kecamatan ..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="px-4 py-2 border border-[#c9ece7] rounded-lg bg-white text-black placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-[#5fb8a8]"
          />
        </div>

        <div className="overflow-x-auto">
          <table className="w-full border-collapse">
            <thead>
              <tr className="border-b border-[#c9ece7] bg-gray-50">
                {["No", "Kabupaten", "Kecamatan", "Desa", "Total KK", "Kesejahteraan", "BUMDES", "Koperasi", "Industri", "Total Skor", "Label"]
                  .map((h, i) => (
                    <th key={i} className="px-4 py-3 text-left text-black font-semibold text-sm">{h}</th>
                  ))}
              </tr>
            </thead>
            <tbody>
              {paginatedData.length > 0 ? (
                paginatedData.map((item, index) => (
                  <tr key={index} className="border-b border-[#e0e0e0] hover:bg-gray-50 transition-colors">
                    <td className="px-4 py-3 text-black text-sm">{startIndex + index + 1}</td>
                    <td className="px-4 py-3 text-black text-sm">{item.NAMA_KAB}</td>
                    <td className="px-4 py-3 text-black text-sm">{item.NAMA_KEC}</td>
                    <td className="px-4 py-3 text-black font-medium text-sm">{item.NAMA_DESA}</td>
                    <td className="px-4 py-3 text-black text-sm">{item.total_kk}</td>
                    <td className="px-4 py-3 text-black text-sm">{item.skor_kesejahteraan.toFixed(1)}</td>
                    <td className="px-4 py-3 text-black text-sm">{item.skor_bumdes.toFixed(1)}</td>
                    <td className="px-4 py-3 text-black text-sm">{item.skor_koperasi.toFixed(1)}</td>
                    <td className="px-4 py-3 text-black text-sm">{item.skor_industri.toFixed(1)}</td>
                    <td className="px-4 py-3 text-black font-semibold text-sm">{item.skor_ekonomi_total.toFixed(1)}</td>
                    <td className="px-4 py-3 text-sm">
                      <span className="inline-block px-3 py-1 bg-gray-100 text-gray-800 rounded-full text-xs font-medium">
                        {item.label}
                      </span>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={11} className="px-4 py-6 text-center text-gray-500">
                    Tidak ada data ditemukan
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mt-6 pt-6 border-t border-[#c9ece7]">
          <div className="text-black text-sm">
            Menampilkan {paginatedData.length > 0 ? startIndex + 1 : 0} - {Math.min(endIndex, filteredData.length)} dari{" "}
            {filteredData.length.toLocaleString()} data
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setCurrentPage((prev) => Math.max(prev - 1, 1))}
              disabled={currentPage === 1}
              className="px-4 py-2 border border-[#c9ece7] rounded-lg text-black font-medium disabled:opacity-50 disabled:cursor-not-allowed hover:bg-gray-50 transition-colors"
            >
              Sebelumnya
            </button>
            <div className="flex items-center gap-1">
              <span className="text-black text-sm">Halaman</span>
              <input
                type="number"
                min="1"
                max={totalPages}
                value={currentPage}
                onChange={(e) => {
                  const page = Math.max(1, Math.min(totalPages, parseInt(e.target.value) || 1))
                  setCurrentPage(page)
                }}
                className="w-16 px-2 py-2 border border-[#c9ece7] rounded-lg text-black text-center focus:outline-none focus:ring-2 focus:ring-[#5fb8a8]"
              />
              <span className="text-black text-sm">dari {totalPages}</span>
            </div>
            <button
              onClick={() => setCurrentPage((prev) => Math.min(prev + 1, totalPages))}
              disabled={currentPage === totalPages}
              className="px-4 py-2 border border-[#c9ece7] rounded-lg text-black font-medium disabled:opacity-50 disabled:cursor-not-allowed hover:bg-gray-50 transition-colors"
            >
              Selanjutnya
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}