"use client"

import { useEffect, useMemo, useState } from "react"
import dynamic from "next/dynamic"
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from "recharts"

interface TipologiData {
  IDDESA: string
  NAMA_KAB: string
  NAMA_KEC: string
  NAMA_DESA: string
  Latitude: number
  Longitude: number
  total_kk: number
  total_penduduk: number
  skor_akses_dasar: number
  skor_konektivitas: number
  skor_pengelolaan_lingkungan: number
  skor_kesejahteraan: number
  skor_kelembagaan_ekonomi: number
  skor_produktivitas_ekonomi: number
  skor_akses_kesehatan: number
  skor_kualitas_kesehatan: number
  skor_program_kesehatan: number
  skor_pendidikan_dasar: number
  skor_pendidikan_lanjut: number
  skor_literasi_masyarakat: number
  skor_kualitas_lingkungan: number
  skor_ketahanan_bencana: number
  skor_digital_readiness: number
  sektor_pertanian: number
  sektor_industri: number
  sektor_jasa: number
  ada_pades: number
  ada_bumdes: number
  ada_sid: number
  kelengkapan_pendidikan: number
  ada_vokasi: number
  ada_mitigasi_bencana: number
  ada_literasi_digital: number
  cluster: number
  label: string
}

const MapComponent = dynamic(() => import("./MapComponent"), {
  ssr: false,
  loading: () => <div className="h-96 bg-white/80 backdrop-blur-sm rounded-lg animate-pulse" />,
})

const COLORS = ["#1d2415", "#697857", "#37432b", "#8b907c", "#a8a97a"]
const ITEMS_PER_PAGE = 10

export default function OverviewPage() {
  const [data, setData] = useState<TipologiData[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")
  const [currentPage, setCurrentPage] = useState(1)
  const [filteredData, setFilteredData] = useState<TipologiData[]>([])
  const [totalPages, setTotalPages] = useState(0)
  const [startIndex, setStartIndex] = useState(0)
  const [endIndex, setEndIndex] = useState(0)
  const [paginatedData, setPaginatedData] = useState<TipologiData[]>([])

  const safeToFixed = (value: number | null, decimals = 1): string => {
    if (value === null || value === undefined || isNaN(value)) return "N/A"
    return Number(value).toFixed(decimals)
  }

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch("http://127.0.0.1:8000/api/tipologi-desa")
        const result = await response.json()
        if (Array.isArray(result)) {
          setData(result)
        } else {
          setData([])
        }
      } catch (error) {
        console.error("Error fetching tipologi data:", error)
        setData([])
      } finally {
        setLoading(false)
      }
    }

    fetchData()
  }, [])

  useEffect(() => {
    const newFilteredData = data.filter(
      (item) =>
        item.NAMA_DESA?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item.NAMA_KEC?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item.NAMA_KAB?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item.label?.toLowerCase().includes(searchTerm.toLowerCase()),
    )
    setFilteredData(newFilteredData)
    setTotalPages(Math.ceil(newFilteredData.length / ITEMS_PER_PAGE))
    setCurrentPage(1)
  }, [data, searchTerm])

  useEffect(() => {
    const newStartIndex = (currentPage - 1) * ITEMS_PER_PAGE
    const newEndIndex = newStartIndex + ITEMS_PER_PAGE
    setStartIndex(newStartIndex)
    setEndIndex(newEndIndex)
    setPaginatedData(filteredData.slice(newStartIndex, newEndIndex))
  }, [currentPage, filteredData])

  const mapMarkers = useMemo(() => {
    return data
      .filter((item) => item.Latitude != null && item.Longitude != null)
      .map((item) => ({
        name: `${item.NAMA_DESA}, ${item.NAMA_KEC}`,
        position: [item.Latitude, item.Longitude] as [number, number],
      }))
  }, [data])

  const aksesDasarByKab = data
    .reduce(
      (acc, item) => {
        const existing = acc.find((x) => x.name === item.NAMA_KAB)
        if (existing) {
          existing.total += item.skor_akses_dasar || 0
          existing.count += 1
        } else {
          acc.push({
            name: item.NAMA_KAB,
            total: item.skor_akses_dasar || 0,
            count: 1,
          })
        }
        return acc
      },
      [] as Array<{ name: string; total: number; count: number }>,
    )
    .map((item) => ({
      name: item.name,
      "Akses Dasar": Number((item.total / item.count).toFixed(1)),
    }))

  const kesejahteraanByKab = data
    .reduce(
      (acc, item) => {
        const existing = acc.find((x) => x.name === item.NAMA_KAB)
        if (existing) {
          existing.total += item.skor_kesejahteraan || 0
          existing.count += 1
        } else {
          acc.push({
            name: item.NAMA_KAB,
            total: item.skor_kesejahteraan || 0,
            count: 1,
          })
        }
        return acc
      },
      [] as Array<{ name: string; total: number; count: number }>,
    )
    .map((item) => ({
      name: item.name,
      Kesejahteraan: Number((item.total / item.count).toFixed(1)),
    }))

  const komponenNasionalData = [
    {
      name: "Akses Dasar",
      avg: Number(
        (
          data.filter((d) => d.skor_akses_dasar).reduce((sum, d) => sum + (d.skor_akses_dasar || 0), 0) /
            data.filter((d) => d.skor_akses_dasar).length || 0
        ).toFixed(1),
      ),
    },
    {
      name: "Konektivitas",
      avg: Number(
        (
          data.filter((d) => d.skor_konektivitas).reduce((sum, d) => sum + (d.skor_konektivitas || 0), 0) /
            data.filter((d) => d.skor_konektivitas).length || 0
        ).toFixed(1),
      ),
    },
    {
      name: "Lingkungan",
      avg: Number(
        (
          data
            .filter((d) => d.skor_kualitas_lingkungan)
            .reduce((sum, d) => sum + (d.skor_kualitas_lingkungan || 0), 0) /
            data.filter((d) => d.skor_kualitas_lingkungan).length || 0
        ).toFixed(1),
      ),
    },
    {
      name: "Kesejahteraan",
      avg: Number(
        (
          data.filter((d) => d.skor_kesejahteraan).reduce((sum, d) => sum + (d.skor_kesejahteraan || 0), 0) /
            data.filter((d) => d.skor_kesejahteraan).length || 0
        ).toFixed(1),
      ),
    },
    {
      name: "Kesehatan",
      avg: Number(
        (
          data.filter((d) => d.skor_akses_kesehatan).reduce((sum, d) => sum + (d.skor_akses_kesehatan || 0), 0) /
            data.filter((d) => d.skor_akses_kesehatan).length || 0
        ).toFixed(1),
      ),
    },
    {
      name: "Pendidikan",
      avg: Number(
        (
          data.filter((d) => d.skor_pendidikan_dasar).reduce((sum, d) => sum + (d.skor_pendidikan_dasar || 0), 0) /
            data.filter((d) => d.skor_pendidikan_dasar).length || 0
        ).toFixed(1),
      ),
    },
  ]

  const sektorData = [
    {
      name: "Pertanian",
      count: data.filter((d) => d.sektor_pertanian === 1).length,
    },
    {
      name: "Industri",
      count: data.filter((d) => d.sektor_industri === 1).length,
    },
    {
      name: "Jasa",
      count: data.filter((d) => d.sektor_jasa === 1).length,
    },
  ]

  const infraProgramData = [
    {
      name: "PADES",
      value: data.filter((d) => d.ada_pades === 1).length,
    },
    {
      name: "BUMDES",
      value: data.filter((d) => d.ada_bumdes === 1).length,
    },
    {
      name: "SID",
      value: data.filter((d) => d.ada_sid === 1).length,
    },
    {
      name: "Vokasi",
      value: data.filter((d) => d.ada_vokasi === 1).length,
    },
    {
      name: "Mitigasi Bencana",
      value: data.filter((d) => d.ada_mitigasi_bencana === 1).length,
    },
    {
      name: "Literasi Digital",
      value: data.filter((d) => d.ada_literasi_digital === 1).length,
    },
  ]

  const clusterDistribution = data.reduce(
    (acc, item) => {
      const existing = acc.find((x) => x.name === item.label)
      if (existing) {
        existing.value += 1
      } else {
        acc.push({ name: item.label, value: 1 })
      }
      return acc
    },
    [] as Array<{ name: string; value: number }>,
  )

  const stats = {
    totalDesa: data.length,
    avgAksesDasar: safeToFixed(data.reduce((sum, d) => sum + (d.skor_akses_dasar || 0), 0) / data.length),
    avgKesejahteraan: safeToFixed(data.reduce((sum, d) => sum + (d.skor_kesejahteraan || 0), 0) / data.length),
    avgDigital: safeToFixed(data.reduce((sum, d) => sum + (d.skor_digital_readiness || 0), 0) / data.length),
  }

  if (loading) {
    return <div className="p-8 text-black">Loading...</div>
  }

  return (
    <div className="space-y-6 p-8">
      <div>
        <h1 className="text-3xl font-bold text-black mb-2">Dashboard Overview Desa</h1>
        <p className="text-gray-600">Tipologi desa berdasarkan klaster multidimensional</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="border border-[#c9ece7] bg-white/80 backdrop-blur-sm rounded-lg p-6">
          <p className="text-black text-sm font-medium">Total Desa</p>
          <p className="text-3xl font-bold text-black mt-2">{stats.totalDesa}</p>
        </div>
        <div className="border border-[#c9ece7] bg-white/80 backdrop-blur-sm rounded-lg p-6">
          <p className="text-black text-sm font-medium">Rata-rata Akses Dasar</p>
          <p className="text-3xl font-bold text-black mt-2">{stats.avgAksesDasar}</p>
        </div>
        <div className="border border-[#c9ece7] bg-white/80 backdrop-blur-sm rounded-lg p-6">
          <p className="text-black text-sm font-medium">Rata-rata Kesejahteraan</p>
          <p className="text-3xl font-bold text-black mt-2">{stats.avgKesejahteraan}</p>
        </div>
        <div className="border border-[#c9ece7] bg-white/80 backdrop-blur-sm rounded-lg p-6">
          <p className="text-black text-sm font-medium">Rata-rata Digital Ready</p>
          <p className="text-3xl font-bold text-black mt-2">{stats.avgDigital}</p>
        </div>
      </div>

      {/* Map */}
      <div className="bg-white/80 backdrop-blur-sm border border-[#c9ece7] rounded-lg overflow-hidden">
        <h2 className="text-lg font-semibold text-black p-3 pb-2">
          Sebaran Desa di Jawa Timur ({filteredData.length} desa)
        </h2>
        <div className="h-96 w-full">
          <MapComponent markers={mapMarkers} />
        </div>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Chart 1: Akses Dasar per Kabupaten */}
        <div className="border border-[#c9ece7] bg-white/80 backdrop-blur-sm rounded-lg p-6">
          <h2 className="text-lg font-semibold text-black mb-4">Rata-rata Skor Akses Dasar per Kabupaten</h2>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={aksesDasarByKab}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e0e0e0" />
              <XAxis dataKey="name" stroke="#666" angle={-45} textAnchor="end" height={80} fontSize={12} />
              <YAxis stroke="#666" />
              <Tooltip contentStyle={{ backgroundColor: "#f5f5f5", border: "1px solid #ccc" }} />
              <Legend />
              <Bar dataKey="Akses Dasar" fill="#1d2415" />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Chart 2: Kesejahteraan per Kabupaten */}
        <div className="border border-[#c9ece7] bg-white/80 backdrop-blur-sm rounded-lg p-6">
          <h2 className="text-lg font-semibold text-black mb-4">Rata-rata Skor Kesejahteraan per Kabupaten</h2>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={kesejahteraanByKab}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e0e0e0" />
              <XAxis dataKey="name" stroke="#666" angle={-45} textAnchor="end" height={80} fontSize={12} />
              <YAxis stroke="#666" />
              <Tooltip contentStyle={{ backgroundColor: "#f5f5f5", border: "1px solid #ccc" }} />
              <Legend />
              <Line type="monotone" dataKey="Kesejahteraan" stroke="#1d2415" strokeWidth={2} />
            </LineChart>
          </ResponsiveContainer>
        </div>

        {/* Chart 3: Komponen Nasional */}
        <div className="border border-[#c9ece7] bg-white/80 backdrop-blur-sm rounded-lg p-6">
          <h2 className="text-lg font-semibold text-black mb-4">Rata-rata Skor Komponen Nasional</h2>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={komponenNasionalData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e0e0e0" />
              <XAxis dataKey="name" stroke="#666" angle={-45} textAnchor="end" height={80} fontSize={12} />
              <YAxis stroke="#666" />
              <Tooltip contentStyle={{ backgroundColor: "#f5f5f5", border: "1px solid #ccc" }} />
              <Legend />
              <Bar dataKey="avg" fill="#697857" name="Skor" />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Chart 4: Sektor Dominan */}
        <div className="border border-[#c9ece7] bg-white/80 backdrop-blur-sm rounded-lg p-6">
          <h2 className="text-lg font-semibold text-black mb-4">Jumlah Desa per Sektor Dominan</h2>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={sektorData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e0e0e0" />
              <XAxis dataKey="name" stroke="#666" />
              <YAxis stroke="#666" />
              <Tooltip contentStyle={{ backgroundColor: "#f5f5f5", border: "1px solid #ccc" }} />
              <Legend />
              <Bar dataKey="count" fill="#37432b" name="Jumlah Desa" />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Chart 5: Infrastruktur & Program */}
        <div className="border border-[#c9ece7] bg-white/80 backdrop-blur-sm rounded-lg p-6">
          <h2 className="text-lg font-semibold text-black mb-4">Ketersediaan Infrastruktur & Program</h2>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={infraProgramData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e0e0e0" />
              <XAxis dataKey="name" stroke="#666" angle={-45} textAnchor="end" height={80} fontSize={12} />
              <YAxis stroke="#666" />
              <Tooltip contentStyle={{ backgroundColor: "#f5f5f5", border: "1px solid #ccc" }} />
              <Legend />
              <Bar dataKey="value" fill="#8b907c" name="Jumlah Desa" />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Chart 6: Cluster Distribution */}
        <div className="border border-[#c9ece7] bg-white/80 backdrop-blur-sm rounded-lg p-6">
          <h2 className="text-lg font-semibold text-black mb-4">Distribusi Kluster Tipologi Desa</h2>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={clusterDistribution}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={({ name, percent }) => `${(percent * 100).toFixed(0)}%`}
                outerRadius={80}
                fill="#8884d8"
                dataKey="value"
              >
                {clusterDistribution.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Table */}
      <div className="border border-[#c9ece7] bg-white/80 backdrop-blur-sm rounded-lg p-6">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-6">
          <h2 className="text-lg font-semibold text-black">
            Detail Tipologi Desa ({filteredData.length.toLocaleString()} hasil)
          </h2>
          <input
            type="text"
            placeholder="Cari nama desa, kecamatan, kabupaten, atau label ..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="px-4 py-2 border border-[#c9ece7] rounded-lg bg-white text-black placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-[#5fb8a8]"
          />
        </div>

        <div className="overflow-x-auto">
          <table className="w-full border-collapse">
            <thead>
              <tr className="border-b border-[#c9ece7] bg-gray-50">
                <th className="px-4 py-3 text-left text-black font-semibold text-sm">No</th>
                <th className="px-4 py-3 text-left text-black font-semibold text-sm">Kab/Kota</th>
                <th className="px-4 py-3 text-left text-black font-semibold text-sm">Kecamatan</th>
                <th className="px-4 py-3 text-left text-black font-semibold text-sm">Desa</th>
                <th className="px-4 py-3 text-left text-black font-semibold text-sm">Akses Dasar</th>
                <th className="px-4 py-3 text-left text-black font-semibold text-sm">Konektivitas</th>
                <th className="px-4 py-3 text-left text-black font-semibold text-sm">Kesejahteraan</th>
                <th className="px-4 py-3 text-left text-black font-semibold text-sm">Lingkungan</th>
                <th className="px-4 py-3 text-left text-black font-semibold text-sm">Digital Ready</th>
                <th className="px-4 py-3 text-left text-black font-semibold text-sm">Sektor</th>
                <th className="px-4 py-3 text-left text-black font-semibold text-sm">Label</th>
              </tr>
            </thead>
            <tbody>
              {paginatedData.length > 0 ? (
                paginatedData.map((item, index) => {
                  const sektor =
                    item.sektor_pertanian === 1 ? "Pertanian" : item.sektor_industri === 1 ? "Industri" : "Jasa"
                  return (
                    <tr key={index} className="border-b border-[#e0e0e0] hover:bg-gray-50 transition-colors">
                      <td className="px-4 py-3 text-black text-sm">{startIndex + index + 1}</td>
                      <td className="px-4 py-3 text-black text-sm">{item.NAMA_KAB}</td>
                      <td className="px-4 py-3 text-black text-sm">{item.NAMA_KEC}</td>
                      <td className="px-4 py-3 text-black font-medium text-sm">{item.NAMA_DESA}</td>
                      <td className="px-4 py-3 text-black text-sm">{safeToFixed(item.skor_akses_dasar)}</td>
                      <td className="px-4 py-3 text-black text-sm">{safeToFixed(item.skor_konektivitas)}</td>
                      <td className="px-4 py-3 text-black text-sm">{safeToFixed(item.skor_kesejahteraan)}</td>
                      <td className="px-4 py-3 text-black text-sm">{safeToFixed(item.skor_kualitas_lingkungan)}</td>
                      <td className="px-4 py-3 text-black text-sm">{safeToFixed(item.skor_digital_readiness)}</td>
                      <td className="px-4 py-3 text-black text-sm">{sektor}</td>
                      <td className="px-4 py-3 text-sm">
                        <span className="inline-block px-3 py-1 bg-gray-100 text-gray-800 rounded-full text-xs font-medium">
                          {item.label || "N/A"}
                        </span>
                      </td>
                    </tr>
                  )
                })
              ) : (
                <tr>
                  <td colSpan={11} className="px-4 py-6 text-center text-gray-500">
                    Tidak ada data ditemukan
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mt-6 pt-6 border-t border-[#c9ece7]">
          <div className="text-black text-sm">
            Menampilkan {paginatedData.length > 0 ? startIndex + 1 : 0} - {Math.min(endIndex, filteredData.length)} dari{" "}
            {filteredData.length.toLocaleString()} data
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setCurrentPage((prev) => Math.max(prev - 1, 1))}
              disabled={currentPage === 1}
              className="px-4 py-2 border border-[#c9ece7] rounded-lg text-black font-medium disabled:opacity-50 disabled:cursor-not-allowed hover:bg-gray-50 transition-colors"
            >
              Sebelumnya
            </button>

            <div className="flex items-center gap-1">
              <span className="text-black text-sm">Halaman</span>
              <input
                type="number"
                min="1"
                max={totalPages}
                value={currentPage}
                onChange={(e) => {
                  const page = Math.max(1, Math.min(totalPages, Number.parseInt(e.target.value) || 1))
                  setCurrentPage(page)
                }}
                className="w-16 px-2 py-2 border border-[#c9ece7] rounded-lg text-black text-center focus:outline-none focus:ring-2 focus:ring-[#5fb8a8]"
              />
              <span className="text-black text-sm">dari {totalPages}</span>
            </div>

            <button
              onClick={() => setCurrentPage((prev) => Math.min(prev + 1, totalPages))}
              disabled={currentPage === totalPages}
              className="px-4 py-2 border border-[#c9ece7] rounded-lg text-black font-medium disabled:opacity-50 disabled:cursor-not-allowed hover:bg-gray-50 transition-colors"
            >
              Selanjutnya
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}
