"use client"

import { useEffect, useState } from "react"
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from "recharts"

interface HealthData {
  NAMA_KAB: string
  NAMA_KEC: string
  NAMA_DESA: string
  total_penduduk: number
  skor_fasilitas: number
  skor_tenaga_kesehatan: number
  skor_gizi: number
  skor_klb: number
  skor_program_prioritas: number
  skor_kesejahteraan: number
  skor_kesehatan_total: number
  cluster: number
  label: string
  puskesmas_per_1000: number
  posyandu_per_1000: number
  dokter_per_1000: number
  bidan_per_1000: number
  Longitude : number
  Latitude : number
}

const COLORS = ["#1d2415", "#697857", "#37432b", "#8b907c", "#a8a97a"]
const ITEMS_PER_PAGE = 10

export default function KeseshatanPage() {
  const [data, setData] = useState<HealthData[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")
  const [currentPage, setCurrentPage] = useState(1)
  const [filteredData, setFilteredData] = useState<HealthData[]>([])
  const [totalPages, setTotalPages] = useState(0)
  const [startIndex, setStartIndex] = useState(0)
  const [endIndex, setEndIndex] = useState(0)
  const [paginatedData, setPaginatedData] = useState<HealthData[]>([])

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch("http://localhost:8000/api/data_cluster/cluster_kesehatan")
        const result = await response.json()
        setData(result)
      } catch (error) {
        console.error("Error fetching health data:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchData()
  }, [])

  useEffect(() => {
    const newFilteredData = data.filter(
      (item) =>
        item.NAMA_DESA.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item.NAMA_KEC.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item.NAMA_KAB.toLowerCase().includes(searchTerm.toLowerCase()),
    )
    setFilteredData(newFilteredData)
    setTotalPages(Math.ceil(newFilteredData.length / ITEMS_PER_PAGE))
    setCurrentPage(1)
  }, [data, searchTerm])

  useEffect(() => {
    const newStartIndex = (currentPage - 1) * ITEMS_PER_PAGE
    const newEndIndex = newStartIndex + ITEMS_PER_PAGE
    setStartIndex(newStartIndex)
    setEndIndex(newEndIndex)
    setPaginatedData(filteredData.slice(newStartIndex, newEndIndex))
  }, [currentPage, filteredData])

  if (loading) {
    return <div className="p-8 text-black">Loading...</div>
  }

  // Chart 1: Average Facility Score by Kabupaten
  const kabupatanChartData = data
    .reduce(
      (acc, item) => {
        const existing = acc.find((x) => x.name === item.NAMA_KAB)
        if (existing) {
          existing.totalFasilitas += item.skor_fasilitas
          existing.count += 1
        } else {
          acc.push({
            name: item.NAMA_KAB,
            totalFasilitas: item.skor_fasilitas,
            count: 1,
          })
        }
        return acc
      },
      [] as Array<{ name: string; totalFasilitas: number; count: number }>,
    )
    .map((item) => ({
      name: item.name,
      fasilitas: Number((item.totalFasilitas / item.count).toFixed(1)),
    }))

  // Chart 2: Average Health Workforce by Kabupaten
  const tenagaByKabupaten = data
    .reduce(
      (acc, item) => {
        const existing = acc.find((x) => x.name === item.NAMA_KAB)
        if (existing) {
          existing.totalTenaga += item.skor_tenaga_kesehatan
          existing.count += 1
        } else {
          acc.push({
            name: item.NAMA_KAB,
            totalTenaga: item.skor_tenaga_kesehatan,
            count: 1,
          })
        }
        return acc
      },
      [] as Array<{ name: string; totalTenaga: number; count: number }>,
    )
    .map((item) => ({
      name: item.name,
      tenaga: Number((item.totalTenaga / item.count).toFixed(1)),
    }))

  // Chart 3: Score Components Distribution (Gizi, KLB, Program)
  const skorComponentChartData = [
    {
      name: "Gizi",
      avg: Number((data.reduce((sum, item) => sum + item.skor_gizi, 0) / data.length).toFixed(1)),
    },
    {
      name: "KLB",
      avg: Number((data.reduce((sum, item) => sum + item.skor_klb, 0) / data.length).toFixed(1)),
    },
    {
      name: "Program",
      avg: Number((data.reduce((sum, item) => sum + item.skor_program_prioritas, 0) / data.length).toFixed(1)),
    },
    {
      name: "Kesejahteraan",
      avg: Number((data.reduce((sum, item) => sum + item.skor_kesejahteraan, 0) / data.length).toFixed(1)),
    },
  ]

  // Chart 4: Health Infrastructure (Facilities per 1000)
  const infraChartData = [
    {
      name: "Puskesmas",
      avg: Number((data.reduce((sum, item) => sum + item.puskesmas_per_1000, 0) / data.length).toFixed(2)),
    },
    {
      name: "Posyandu",
      avg: Number((data.reduce((sum, item) => sum + item.posyandu_per_1000, 0) / data.length).toFixed(2)),
    },
  ]

  // Chart 5: Health Workforce (per 1000)
  const workforceChartData = [
    {
      name: "Dokter",
      avg: Number((data.reduce((sum, item) => sum + item.dokter_per_1000, 0) / data.length).toFixed(2)),
    },
    {
      name: "Bidan",
      avg: Number((data.reduce((sum, item) => sum + item.bidan_per_1000, 0) / data.length).toFixed(2)),
    },
  ]

  const clusterDistribution = data.reduce(
    (acc, item) => {
      const existing = acc.find((x) => x.name === item.label)
      if (existing) {
        existing.value += 1
      } else {
        acc.push({ name: item.label, value: 1 })
      }
      return acc
    },
    [] as Array<{ name: string; value: number }>,
  )

  const stats = {
    totalDesa: data.length,
    avgFasilitas: (data.reduce((sum, item) => sum + item.skor_fasilitas, 0) / data.length).toFixed(1),
    avgTenaga: (data.reduce((sum, item) => sum + item.skor_tenaga_kesehatan, 0) / data.length).toFixed(1),
    avgKesehatan: (data.reduce((sum, item) => sum + item.skor_kesehatan_total, 0) / data.length).toFixed(1),
  }

  const fasilityChartData = data.map((item) => ({
    desa: item.NAMA_DESA,
    puskesmas: item.puskesmas_per_1000,
    posyandu: item.posyandu_per_1000,
  }))

  const tenagaKesehatanChartData = data.map((item) => ({
    desa: item.NAMA_DESA,
    dokter: item.dokter_per_1000,
    bidan: item.bidan_per_1000,
  }))

  const skorChartData = data.map((item) => ({
    desa: item.NAMA_DESA,
    fasilitas: item.skor_fasilitas,
    tenaga: item.skor_tenaga_kesehatan,
    gizi: item.skor_gizi,
    klb: item.skor_klb,
    program: item.skor_program_prioritas,
  }))

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-black mb-2">Analisis Kesehatan Desa</h1>
        <p className="text-gray-600">Data kluster kesehatan masyarakat per desa</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="border border-[#c9ece7] bg-white/80 backdrop-blur-sm rounded-lg p-6">
          <p className="text-black text-sm font-medium">Total Desa</p>
          <p className="text-3xl font-bold text-black mt-2">{stats.totalDesa}</p>
        </div>
        <div className="border border-[#c9ece7] bg-white/80 backdrop-blur-sm rounded-lg p-6">
          <p className="text-black text-sm font-medium">Rata-rata Skor Fasilitas</p>
          <p className="text-3xl font-bold text-black mt-2">{stats.avgFasilitas}</p>
        </div>
        <div className="border border-[#c9ece7] bg-white/80 backdrop-blur-sm rounded-lg p-6">
          <p className="text-black text-sm font-medium">Rata-rata Skor Tenaga</p>
          <p className="text-3xl font-bold text-black mt-2">{stats.avgTenaga}</p>
        </div>
        <div className="border border-[#c9ece7] bg-white/80 backdrop-blur-sm rounded-lg p-6">
          <p className="text-black text-sm font-medium">Rata-rata Skor Kesehatan</p>
          <p className="text-3xl font-bold text-black mt-2">{stats.avgKesehatan}</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="border border-[#c9ece7] bg-white/80 backdrop-blur-sm rounded-lg p-6">
          <h2 className="text-lg font-semibold text-black mb-4">Rata-rata Skor Fasilitas per Kabupaten</h2>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={kabupatanChartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e0e0e0" />
              <XAxis dataKey="name" stroke="#666" angle={-45} textAnchor="end" height={80} fontSize={12} />
              <YAxis stroke="#666" />
              <Tooltip contentStyle={{ backgroundColor: "#f5f5f5", border: "1px solid #ccc" }} />
              <Legend />
              <Bar dataKey="fasilitas" fill="#1d2415" name="Skor Fasilitas" />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="border border-[#c9ece7] bg-white/80 backdrop-blur-sm rounded-lg p-6">
          <h2 className="text-lg font-semibold text-black mb-4">Rata-rata Skor Tenaga Kesehatan per Kabupaten</h2>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={tenagaByKabupaten}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e0e0e0" />
              <XAxis dataKey="name" stroke="#666" angle={-45} textAnchor="end" height={80} fontSize={12} />
              <YAxis stroke="#666" />
              <Tooltip contentStyle={{ backgroundColor: "#f5f5f5", border: "1px solid #ccc" }} />
              <Legend />
              <Line type="monotone" dataKey="tenaga" stroke="#1d2415" strokeWidth={2} name="Skor Tenaga" />
            </LineChart>
          </ResponsiveContainer>
        </div>

        <div className="border border-[#c9ece7] bg-white/80 backdrop-blur-sm rounded-lg p-6">
          <h2 className="text-lg font-semibold text-black mb-4">Rata-rata Skor Komponen Kesehatan (Nasional)</h2>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={skorComponentChartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e0e0e0" />
              <XAxis dataKey="name" stroke="#666" />
              <YAxis stroke="#666" />
              <Tooltip contentStyle={{ backgroundColor: "#f5f5f5", border: "1px solid #ccc" }} />
              <Legend />
              <Bar dataKey="avg" fill="#697857" name="Skor Rata-rata" />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="border border-[#c9ece7] bg-white/80 backdrop-blur-sm rounded-lg p-6">
          <h2 className="text-lg font-semibold text-black mb-4">Fasilitas Kesehatan per 1000 Penduduk (Rata-rata)</h2>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={infraChartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e0e0e0" />
              <XAxis dataKey="name" stroke="#666" />
              <YAxis stroke="#666" />
              <Tooltip contentStyle={{ backgroundColor: "#f5f5f5", border: "1px solid #ccc" }} />
              <Legend />
              <Bar dataKey="avg" fill="#37432b" name="Per 1000 Penduduk" />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="border border-[#c9ece7] bg-white/80 backdrop-blur-sm rounded-lg p-6">
          <h2 className="text-lg font-semibold text-black mb-4">Tenaga Kesehatan per 1000 Penduduk (Rata-rata)</h2>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={workforceChartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e0e0e0" />
              <XAxis dataKey="name" stroke="#666" />
              <YAxis stroke="#666" />
              <Tooltip contentStyle={{ backgroundColor: "#f5f5f5", border: "1px solid #ccc" }} />
              <Legend />
              <Bar dataKey="avg" fill="#8b907c" name="Per 1000 Penduduk" />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Cluster Distribution */}
        <div className="border border-[#c9ece7] bg-white/80 backdrop-blur-sm rounded-lg p-6">
          <h2 className="text-lg font-semibold text-black mb-4">Distribusi Kluster Kesehatan</h2>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={clusterDistribution}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                outerRadius={80}
                fill="#8884d8"
                dataKey="value"
              >
                {clusterDistribution.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="border border-[#c9ece7] bg-white/80 backdrop-blur-sm rounded-lg p-6">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-6">
          <h2 className="text-lg font-semibold text-black">
            Detail Kesehatan Desa ({filteredData.length.toLocaleString()} hasil)
          </h2>
          <input
            type="text"
            placeholder="Cari nama desa, label, kabupaten, atau kecamatan ..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="px-4 py-2 border border-[#c9ece7] rounded-lg bg-white text-black placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-[#5fb8a8]"
          />
        </div>

        <div className="overflow-x-auto">
          <table className="w-full border-collapse">
            <thead>
              <tr className="border-b border-[#c9ece7] bg-gray-50">
                <th className="px-4 py-3 text-left text-black font-semibold text-sm">No</th>
                <th className="px-4 py-3 text-left text-black font-semibold text-sm">Nama Kab/Kota</th>
                <th className="px-4 py-3 text-left text-black font-semibold text-sm">Nama Kecamatan</th>
                <th className="px-4 py-3 text-left text-black font-semibold text-sm">Nama Desa</th>
                <th className="px-4 py-3 text-left text-black font-semibold text-sm">Fasilitas</th>
                <th className="px-4 py-3 text-left text-black font-semibold text-sm">Tenaga</th>
                <th className="px-4 py-3 text-left text-black font-semibold text-sm">Gizi</th>
                <th className="px-4 py-3 text-left text-black font-semibold text-sm">KLB</th>
                <th className="px-4 py-3 text-left text-black font-semibold text-sm">Program</th>
                <th className="px-4 py-3 text-left text-black font-semibold text-sm">Total Skor</th>
                <th className="px-4 py-3 text-left text-black font-semibold text-sm">Label</th>
              </tr>
            </thead>
            <tbody>
              {paginatedData.length > 0 ? (
                paginatedData.map((item, index) => (
                  <tr key={index} className="border-b border-[#e0e0e0] hover:bg-gray-50 transition-colors">
                    <td className="px-4 py-3 text-black text-sm">{startIndex + index + 1}</td>
                    <td className="px-4 py-3 text-black text-sm">{item.NAMA_KAB}</td>
                    <td className="px-4 py-3 text-black text-sm">{item.NAMA_KEC}</td>
                    <td className="px-4 py-3 text-black font-medium text-sm">{item.NAMA_DESA}</td>
                    <td className="px-4 py-3 text-black text-sm">{item.skor_fasilitas.toFixed(1)}</td>
                    <td className="px-4 py-3 text-black text-sm">{item.skor_tenaga_kesehatan.toFixed(1)}</td>
                    <td className="px-4 py-3 text-black text-sm">{item.skor_gizi.toFixed(1)}</td>
                    <td className="px-4 py-3 text-black text-sm">{item.skor_klb.toFixed(1)}</td>
                    <td className="px-4 py-3 text-black text-sm">{item.skor_program_prioritas.toFixed(1)}</td>
                    <td className="px-4 py-3 text-black font-semibold text-sm">
                      {item.skor_kesehatan_total.toFixed(1)}
                    </td>
                    <td className="px-4 py-3 text-sm">
                      <span className="inline-block px-3 py-1 bg-gray-100 text-gray-800 rounded-full text-xs font-medium">
                        {item.label}
                      </span>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={11} className="px-4 py-6 text-center text-gray-500">
                    Tidak ada data ditemukan
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mt-6 pt-6 border-t border-[#c9ece7]">
          <div className="text-black text-sm">
            Menampilkan {paginatedData.length > 0 ? startIndex + 1 : 0} - {Math.min(endIndex, filteredData.length)} dari{" "}
            {filteredData.length.toLocaleString()} data
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setCurrentPage((prev) => Math.max(prev - 1, 1))}
              disabled={currentPage === 1}
              className="px-4 py-2 border border-[#c9ece7] rounded-lg text-black font-medium disabled:opacity-50 disabled:cursor-not-allowed hover:bg-gray-50 transition-colors"
            >
              Sebelumnya
            </button>

            <div className="flex items-center gap-1">
              <span className="text-black text-sm">Halaman</span>
              <input
                type="number"
                min="1"
                max={totalPages}
                value={currentPage}
                onChange={(e) => {
                  const page = Math.max(1, Math.min(totalPages, Number.parseInt(e.target.value) || 1))
                  setCurrentPage(page)
                }}
                className="w-16 px-2 py-2 border border-[#c9ece7] rounded-lg text-black text-center focus:outline-none focus:ring-2 focus:ring-[#5fb8a8]"
              />
              <span className="text-black text-sm">dari {totalPages}</span>
            </div>

            <button
              onClick={() => setCurrentPage((prev) => Math.min(prev + 1, totalPages))}
              disabled={currentPage === totalPages}
              className="px-4 py-2 border border-[#c9ece7] rounded-lg text-black font-medium disabled:opacity-50 disabled:cursor-not-allowed hover:bg-gray-50 transition-colors"
            >
              Selanjutnya
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}
